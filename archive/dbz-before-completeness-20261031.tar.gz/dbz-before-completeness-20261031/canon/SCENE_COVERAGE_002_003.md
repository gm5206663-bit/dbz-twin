# Episode 2–3 scene coverage — current correction draft

**Owns:** the chronological scene inventory for the current abduction/rescue correction. This is an audit aid, not story prose or proof of unseen images. `W-30` is redistributed Japanese caption text of unverified broadcaster provenance; the full spoken material for episodes 2 and 3 was reread on 31 October. No video frames have been inspected. The accepted earlier bodies are unchanged, and Chapter Two's conscious-capture passage is superseded by the written correction in Chapter Four.

## Episode 2

| Local caption time | Source scene or beat | Serial coverage/status |
|---|---|---|
| 02:59–04:30 | Recap of Gohan; Piccolo's reaction to Raditz; Raditz searches for Kakarot. | Earlier chapters; the source-order and visual debts in Chapter One's footer remain explicit. |
| 04:47–06:07 | Bulma arrives at Kame House; gifts, Yamcha and Launch. | Accepted Chapter Two, sections one–two. |
| 06:11–09:30 | Goku and Gohan arrive; family introductions, scholar, tails, Chi-Chi's training rule, Four-Star and the other Dragon Balls. | Accepted Chapter Two, sections two–three; the twin and his dialogue are authored. |
| 09:39–12:10 | The approaching power; Raditz arrives, calls Goku Kakarot; Krillin is struck. | Accepted Chapter Two, sections four–six. Silent choreography remains unverified. |
| 13:57–20:16 | Raditz's tail, Goku's childhood injury, Saiyan identity and mission; Goku's refusal. | Accepted Chapter Two, sections six–seven; earlier source-order debt is not silently repaired. |
| 20:29–22:26 | Raditz describes the surviving Saiyans and recruitment, then threatens Goku's child. | Accepted Chapter Two; the two-child recognition and island 400 are authored. |
| 22:36–24:35 | Goku is struck, a child is taken, and Raditz gives the ultimatum. | **Corrected Chapter Four, sections 1–2 and 5.** Goshin actively fights, his output rises, and Raditz takes him only after a knockout. The old conscious-capture passage in Chapter Two is retained as superseded historical prose. Gohan is conscious and participates. |

## Episode 3

| Local caption time | Source scene or beat | Serial coverage/status |
|---|---|---|
| 02:38–06:06 | Recap, repeated ultimatum, threat to Earth and departure. | Corrected Chapter Four, sections 1–2. Goshin is unconscious during the abduction; the extra fight and two children are authored. |
| 06:13–07:31 | Goku recovers and proposes Raditz's tail as the opportunity. | Chapter Four, section 3; the scene uses the tactic without re-teaching an established rule. |
| 07:41–08:52 | Roshi and Krillin offer to help, including the consequence of prior resurrection. | Chapter Four, section 3. |
| 08:54–10:05 | Bulma proposes a wish; the radar tracks the ball on Gohan's hat. | Chapter Four, section 3. |
| 10:07–12:39 | Piccolo offers a self-interested alliance; Goku agrees and borrows the radar. Goku mentions Nimbus and Piccolo disparages his flying technique. | Chapter Four, section 4. The alliance and radar are dramatized; the previously excluded new Nimbus scene/test is not restaged. Flight staging is authored, not inferred from silent frames. |
| 14:15–14:50 | Roshi, Krillin and Bulma discuss Piccolo and decide to follow. | Chapter Four, section 4; the aircraft is authored. |
| 14:56–15:11 | Chi-Chi thinks Gohan is enjoying himself and discovers unfinished homework. | Accepted Chapter Three; the same moment also appears in Chapter Four, section 6. |
| 15:15–16:38 | Frightened Gohan, Raditz's rebuke, pod confinement and Raditz's wish to find food. | Chapter Four, section 7. Both boys are present; Goshin is unconscious. Gohan actively tries to help him and open the door. |
| 16:42–17:13 | A nearby 710 signal; Raditz suspects his scouter is broken. | Chapter Four, section 7. No explicit identification of the reading as either twin is invented. |
| 17:23–17:51 | Goku and Piccolo approach; the device makes a surprise approach ineffective. | Chapter Four, section 8. |
| 18:00–19:13 | Another 710 signal; 322 and 334 approach; Raditz doubts his machine. | Chapter Four, section 8. Goshin's awakening and escape follow as authored divergence, not a claim of a canon visual. |
| 19:46–21:03 | Goku and Piccolo confront Raditz over the child and Goku's refusal. | Chapter Four, sections 9–10. The children have escaped and Raditz has been fighting Goshin, changing the confrontation's circumstances. |
| 21:06–21:49 | Weighted clothing conversation and 408 / 416 readings. | Chapter Four, section 10. The 408 target's visual identification and removal choreography are not independently frame-verified. |
| 21:51–23:45 | Raditz rejects recruitment and begins fighting; the adults try to deal with his speed and the tail. | Chapter Four, section 10, with Goshin and Gohan's active participation as authored divergence. |
| 23:54–24:18 | Raditz says the other two Saiyans are stronger; narrator closes the episode. | Chapter Four, section 10 and preview. The fight continues in the next sequential chapter, not a recap. |

**Continuity check:** In this draft Raditz never abducts Goshin while he is conscious. Goshin's ~400 island reading is not a ceiling, and his fighting output visibly rises; no new exact personal figure is invented. He is not arbitrarily kept in a pod after waking. Goku, Piccolo, Raditz and both children are alive at the stopping point. This is the user's authored correction for this encounter, not a general canonical rule that a given reading makes capture impossible.
