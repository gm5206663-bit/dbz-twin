#!/usr/bin/env python3
"""Focused regression tests for the Twin checker; uses only temporary fixtures."""
import pathlib
import tempfile
import unittest

import check


class CheckerFixtures(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="twin-check-fixtures-")
        self.previous_root = check.ROOT
        check.ROOT = pathlib.Path(self.temp.name)
        (check.ROOT / "chapters").mkdir()
        check.P.clear()
        check.F.clear()

    def tearDown(self):
        check.ROOT = self.previous_root
        check.P.clear()
        check.F.clear()
        self.temp.cleanup()

    def test_band_includes_cold_open_and_excludes_metadata(self):
        story = (
            "# Chapter Example\n\n```\nMETADATA_DO_NOT_COUNT\n```\n\n"
            "FIRST_SCENE stays here.\n\n---\n\nSECOND_SCENE stays too.\n"
            "## Footer\nFOOTER_DO_NOT_COUNT\n"
        )
        prose = check.band_prose(story)
        self.assertIn("FIRST_SCENE", prose)
        self.assertIn("SECOND_SCENE", prose)
        self.assertNotIn("METADATA_DO_NOT_COUNT", prose)
        self.assertNotIn("FOOTER_DO_NOT_COUNT", prose)

    def test_counting_cold_open_still_rejects_short_chapters(self):
        chapter = check.ROOT / "chapters" / "Chapter_99_Fixture.md"
        lines = []
        for i in range(465):
            words = "One two three four five six seven eight nine ten."
            lines.append('"' + words + '"' if i % 5 < 3 else words)
        chapter.write_text("# Chapter Fixture\n\n" + "\n".join(lines[:100]) +
                           "\n\n---\n\n" + "\n".join(lines[100:]) +
                           "\n\n## Footer\n", encoding="utf-8")
        check.check_band()
        self.assertFalse(check.F, check.F)
        self.assertTrue(any("4650 words" in p for p in check.P), check.P)
        chapter.write_text("# Chapter Fixture\n\n" + "\n".join(lines[:100]) +
                           "\n\n---\n\n" + "\n".join(lines[100:250]) +
                           "\n\n## Footer\n", encoding="utf-8")
        check.P.clear()
        check.F.clear()
        check.check_band()
        self.assertTrue(any("2,500" in f or "2500" in f for f in check.F), check.F)
        self.assertFalse(any("Chapter_99_Fixture" in p for p in check.P), check.P)

    def test_dinosaur_exception_is_exact_and_does_not_hide_other_matches(self):
        chapter = check.ROOT / "chapters" / "Chapter_08_The_Dinosaur_by_the_River.md"
        reviewed = ("The large dinosaur breaks through the falling mud. "
                    "Gohan sets the small one down and backs away.")
        chapter.write_text("# Chapter Eight\n\nGoshin watches.\n\n" + reviewed + "\n", encoding="utf-8")
        check.check_names()
        self.assertFalse(check.F, check.F)
        check.P.clear()
        check.F.clear()
        chapter.write_text("# Chapter Eight\n\nGoshin watches.\n\n" + reviewed +
                           "\n\nThe small one returns to his brother.\n", encoding="utf-8")
        check.check_names()
        self.assertTrue(any("the small one" in f for f in check.F), check.F)


if __name__ == "__main__":
    unittest.main(verbosity=2)
