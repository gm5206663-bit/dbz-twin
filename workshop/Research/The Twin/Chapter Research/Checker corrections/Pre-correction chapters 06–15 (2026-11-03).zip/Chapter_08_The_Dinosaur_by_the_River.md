# Chapter Eight — The Dinosaur by the River

A strip of bandage catches on a low branch. Beneath it, two pairs of shoes press into the wet ground.

**THE DINOSAUR BY THE RIVER**

**NARRATOR:** Gohan and Goshin have escaped Piccolo's grasp, but he is still close behind. Downriver, their injured father is coming after them.

---

## The Other Bank

Gohan pulls the strip of bandage free and tucks it around Goshin's palm. His own shoulder hurts when he lifts his arm, so Goshin holds the end while he ties it.

"Can you see Nimbus?" Gohan asks.

Goshin looks through the branches. A yellow edge moves above the trees.

"He's up there."

"Nimbus! Come down!"

The cloud dips toward them. A blast flashes through the branches, and Nimbus darts aside. Splinters fall around the boys.

Piccolo steps between the trees behind them, brushing splintered branches aside.

"You can't hide in the trees forever."

Goshin stands in front of Gohan. "We only have to get past you."

"You haven't managed it yet."

Gohan looks toward the river. "Father's down there."

"Your father can barely stand."

"We're going to him."

Piccolo folds his arms. "You want to survive the Saiyans? Spend six months out here first. Find your own food. Learn what hunts you. Then I'll teach you to fight."

"Six months?" Gohan says. "What about Mother? What about school?"

"If you can't stay alive, you won't need school."

"And where are we supposed to sleep?"

"On the ground."

Goshin looks at the mud beneath his shoes. "It's wet."

"Then find somewhere dry."

"Mother has beds," Gohan says.

"Your mother won't be there when the Saiyans come."

Gohan takes Goshin's good hand. "She'll be with us."

Piccolo lifts one hand. Goshin pulls Gohan behind the tree. The trunk shudders as a blast strikes the place where they stood.

"Go toward the river," Goshin says.

Gohan runs down the sloping path. Goshin rises from the ground and flies beside him on the downhill side, keeping close enough to reach him.

Piccolo comes over the fallen branches. He raises his hand again, but a heavy crash sounds farther ahead. Another follows it, and the ground shakes under Gohan's feet.

A tree bends. Something pushes through it.

Gohan stops so abruptly that Goshin nearly flies past him.

A dinosaur's head rises above the ferns. Its jaws open, showing rows of teeth.

"Goshin," Gohan says.

"I see it."

The dinosaur lunges. Goshin catches Gohan around the waist and lifts him clear. The jaws snap shut beneath them, and the dinosaur's head drives into the tree.

Branches come down. Goshin carries Gohan above the first row, but Piccolo is waiting over the canopy.

"I'll stop you here," Piccolo says.

He reaches for Gohan. Goshin twists away, and the three of them drop through the leaves toward the riverbank.

Goshin sets Gohan on his feet. He puts his weight on the ankle Piccolo gripped; the red mark has already faded. Gohan scrambles beneath a fallen trunk, and Goshin follows with both hands free.

The dinosaur's claws rake the bark above them.

"It can't get under," Gohan says.

The trunk rolls.

"It can move it!" Goshin says.

They hurry out the other side. The dinosaur tears the trunk away and comes after them along the bank.

Goshin fires at the ground beside its feet. Mud bursts up against its legs, and the dinosaur turns toward him. Gohan waves both arms from behind a rock.

"Over here!"

The dinosaur swings back. Goshin flies to the other side, and the boys lead it around the rock instead of toward the river.

Gohan's foot slides on wet stones. He grabs a hanging vine and swings out of the dinosaur's reach. The vine carries him into a patch of nettles.

"Ow!"

"Are you bitten?" Goshin calls.

"No. The plants got me."

The dinosaur reaches past the rock. Gohan ducks, but its teeth catch the vine above him. It pulls, shaking leaves down over his hat.

Goshin fires a narrow burst at the end of the vine. It breaks above the dinosaur's jaws. The animal recoils with a mouthful of leaves, and Gohan runs clear.

"That wasn't lunch," Gohan calls back.

"Don't tell it!" Goshin says.

The dinosaur gives a roar and stomps after Gohan. Goshin circles behind it, but Piccolo drops from the trees into his path.

"Are you going to fight it or run?"

"Both," Goshin says.

He darts beneath Piccolo's arm and joins Gohan behind the rock. Piccolo lands on the higher bank, watching the dinosaur swing its head toward the boys.

A thin cry comes from behind the rock. Gohan stops.

"Did you hear that?"

The dinosaur charges again. Goshin pushes Gohan clear, and its snout strikes the rock between them.

The cry comes a second time.

---

## The Aircraft

Bulma kneels beside the damaged tail. A bent control rod hangs out of its housing, with blackened wiring caught beneath it.

She opens her toolkit and takes out a pair of pliers. The rod will not move until she cuts the wire away.

"That's one problem," she says. "Now I only have the rest of the aircraft."

A shadow passes over the clearing. Bulma looks up.

Mr. Popo descends on a carpet and lands beside her.

"Popo?"

"Kami sent me to help. Where is Goku?"

"He and Roshi went up the river. Piccolo's after the boys."

Popo looks toward the trees. "I'll find them."

He reaches the carpet, then pauses. Bulma has taken the wrapped scouter from her pocket.

"Can you fix it?" he asks.

"I can try. I need tools that fit this casing."

She shows him the edge. None of the drivers in her hand matches the tiny slots.

"I'm not putting its cell back in while it might be transmitting. I'll take it to my lab when I can."

Popo nods and rises above the clearing. Bulma wraps the scouter again, puts it away from the separate cell, and returns to the bent rod.

---

## The Road

Ox-King's truck rounds a bend on the way to the coast. Chi-Chi leans forward in her seat, watching the sky above the trees.

A figure in orange flies over the road. Chi-Chi opens the window.

"Krillin!"

Krillin turns at her voice and drops beside the truck. Ox-King brakes hard enough to scatter gravel.

Chi-Chi is out before the wheels have stopped. "Where are Goku and the boys? Turtle told me someone took them."

"They got away from Raditz," Krillin says. "Goku and Piccolo beat him."

"Are the boys hurt?"

"They were both awake when I left. Gohan hurt his shoulder. Goshin's head and hand were hurt."

"And Goku?"

Krillin touches the bag inside his shirt. "He's alive, but he was hurt badly. I went to Korin for beans."

"How badly?"

"I saw burns on his arm, and he was holding his ribs. He was talking to us when I left."

"When was that?"

"Before the aircraft took off."

Chi-Chi catches his arm. "Take me to them."

"I'm going there now. I can feel the boys, and Piccolo's near them, but I don't know what he's doing."

"He went after the man who took them, didn't he?"

"With Goku. They fought Raditz together."

"Then let's find out why he's still with my sons."

Ox-King climbs down from the truck. "I'll follow as far as the road goes."

He reaches into the cab and gives Chi-Chi the first-aid box. The folded blanket slips out after it, and he catches it against his chest.

"I'll bring this too."

"If you see Turtle, tell him we're going to the boys."

"I will."

Chi-Chi keeps hold of the box. Krillin lifts her, and they rise above the trees.

"Which way?" she asks.

Krillin turns toward the mountains. "There."

The truck starts below them.

---

## The Small Cry

Gohan edges around the rock. Beyond it, a narrow channel runs between the bank and a fallen slab. A small dinosaur is caught beneath a thick root, with water rising around its feet.

The large dinosaur comes after Gohan. Goshin flies between them and fires into the water. The spray strikes its face, and Gohan gets back behind the rock.

"There's a little one," he says. "It's stuck."

Goshin looks around the edge. The small dinosaur pulls at its leg, but the root holds it fast.

"That rock might have come from the cliff," Gohan says. "When I broke it."

"Let's get it out."

"What about the big one?"

"We'll have to keep it away."

Goshin rises above the rock. The dinosaur snaps at him, and he flies across the channel. It follows him, leaving Gohan room to reach the root.

Gohan puts both hands under it and pulls. His shoulder catches, and the root does not move.

Goshin lands beside him. "I can lift the rock."

He wedges both hands beneath the slab and pushes. The slab lifts, but the root is caught in a crack under it. Water rushes into the space he has opened.

"There's a stick," Gohan says. "I can get it under the root."

He retrieves a broken branch and feeds its end into the crack. The small dinosaur twists away from him, tugging its trapped leg.

"Easy," Gohan says. "I'm trying to help."

The dinosaur snaps at his sleeve. Gohan jerks his hand back, then reaches for the branch again. The wet wood slips, and the end of the branch catches under the wrong root.

"I can't see its foot."

Goshin lowers his head to look beneath the slab. "The other root is holding it. The one by the water."

Gohan shifts the branch. Water covers the toe of his shoe as he pushes it into the crack again.

"This one?"

"That's it."

Gohan presses down. The root moves a little, but the slab tilts toward the small dinosaur. Goshin catches the weight against his shoulder before it can fall.

"I don't want to break the rock," he says. "It'll land on you."

"Can you keep it there?"

"Yes."

Gohan pulls a loose stone from the edge of the channel and wedges it under the branch. The branch holds its place this time. He takes a breath and looks at Goshin.

"Lift it on three," he tells him.

"Lift it on three."

"One. Two. Three!"

Goshin raises the slab. Gohan pushes the branch down. The root rises enough for the small dinosaur to pull its leg free, but it scrambles the wrong way, deeper beneath the slab.

"No, this way!"

The large dinosaur charges down the bank. Goshin cannot leave the slab without dropping it onto Gohan and the small dinosaur.

He shifts his feet and raises his bandaged palm toward the teeth. He fires into the shallow water ahead of the dinosaur, and its leading foot slips on the wet stones.

It catches itself and comes on.

Gohan crawls farther under the slab. The small dinosaur presses against the bank, snapping at him each time he reaches for it.

"I won't hurt you," he says, although his voice shakes.

The jaws open above Goshin. He keeps one shoulder against the rock and pulls his good hand free to aim.

Piccolo fires from the trees. His blast strikes the bank in front of the dinosaur, throwing up a wall of mud. The dinosaur skids sideways, and the small dinosaur cries out beneath Gohan's arm.

"You're no use to me dead," Piccolo calls.

Goshin blinks mud from his eyes. "We didn't ask you."

"I didn't ask you to stop for an animal."

The slab presses down. Goshin plants his feet and pushes it up again. Gohan puts his torn sleeve between his hand and the small dinosaur's teeth, then catches it around the middle.

It kicks and wriggles. Gohan's shoulder hurts, but he keeps hold and pulls it out of the channel.

"Goshin, it's clear!"

Goshin pushes the slab away. It lands in the empty channel with a heavy splash. He flies over it and comes down beside Gohan.

The large dinosaur breaks through the falling mud. Gohan sets the small one down and backs away.

The small dinosaur runs to the larger animal. It turns once, then follows as the adult pushes through the ferns and takes it up the bank.

Gohan's knees give way. He sits in the wet grass and watches the ferns settle.

"It got out," he says.

Goshin helps him up. "You got it out."

"We did. I was afraid it would bite you."

"I was afraid it would bite you," Goshin says.

Gohan takes his hand. They hurry toward the river, with Goshin on the downhill side of the path. A red apple hangs above them, and Gohan snatches it as they pass. He takes a bite without stopping.

His face folds. "Sour!"

Goshin looks at the apple. "Mother didn't wash it."

"Mother would make curry."

"With potatoes," Goshin says.

"Or steamed buns. Or shumai."

Gohan takes another small bite and makes the same face. Goshin laughs, then touches the place where Raditz struck him.

"It doesn't hurt now," he says.

"Good," Gohan says. "Don't press it again."

"Don't press it again," Goshin repeats.

Piccolo lands across the channel.

"Finished?"

Gohan drops the apple. Goshin gets up.

"You helped us," Gohan says.

"I stopped the animal. You still have a year before the Saiyans arrive."

"We don't want to go with you."

"I know."

Piccolo's arm stretches toward Gohan. Goshin strikes the wrist aside. Gohan calls Nimbus, and the cloud comes through the broken branches.

Piccolo reaches again. Gohan jumps onto Nimbus and steers it between two trees. Goshin flies beside him.

Piccolo's arm follows them through the gap, then curls around the nearer trunk. His hand catches Gohan's sleeve.

Gohan turns Nimbus sharply around the other side. The sleeve tears free, and Piccolo's arm tightens against the trunk. Goshin kicks the trapped wrist as Piccolo pulls it back. Bark strips away, and the hand misses Gohan by inches.

Piccolo rips his arm clear and rises above the branches. A blast comes after them. Goshin turns his hand and sends it down into the river. Water erupts behind them, hiding the bank.

"Father!" Gohan calls.

A voice answers through the trees.

"Gohan! Goshin!"

Nimbus carries Gohan toward it, with Goshin flying close beside him.

*This programme continues after a message.*

---

## The Carpet

Goku leans on Roshi as they follow the river. At the sound of Gohan's voice, he takes another step and nearly falls.

"I'm coming!" he calls.

A carpet drops through the gap above them. Popo stands on it.

"Get on," he says. "I'll take you to them."

Roshi helps Goku onto the carpet and climbs on with the medical case. Popo lifts them above the water.

Nimbus comes around the bend, carrying Gohan, with Goshin flying at its side. Goku reaches out. Gohan guides Nimbus alongside the carpet, and Goshin catches the edge to keep the two level.

"Father!"

"You're both here."

Gohan steps across and wraps his good arm around Goku. Goshin lands beside him and keeps hold of Goku's hand.

"Are you hurt again?" Goku asks.

"My shoulder," Gohan says. "The dinosaur didn't bite us."

Goku looks at Goshin. "What happened?"

"There were two dinosaurs. Piccolo stopped the big one."

"Then he chased us again," Gohan says.

Piccolo rises above the trees behind them.

Roshi puts the medical case between Goku and the edge of the carpet. Popo turns to face Piccolo.

"Leave them alone," Goku says.

"You can't protect them lying down."

Goshin moves beside his father. Gohan takes his hat off and holds it against his chest.

A second voice comes from above the river.

"Goku!"

Krillin descends with Chi-Chi. He lands on the bank, and Chi-Chi is running toward the carpet before he has both feet on the ground. Popo brings it beside the bank.

"Mother!" Gohan calls.

Krillin takes a bean from the bag and tosses it to Goku. Goku catches it, puts it in his mouth and swallows.

He takes a full breath. He moves his arm, then rises from the carpet without Roshi's help. The pain is gone, and his strength is back.

Piccolo watches him.

"You're not taking my sons," Goku says.

Chi-Chi reaches the carpet and steps aboard. She draws Gohan close with one arm and puts the other around Goshin, then looks up at Piccolo.

"You stay away from them."

"When the Saiyans come, that won't keep them alive."

"Then we'll prepare for them," Goku says. "Together."

Piccolo looks at Goku and the two boys, then at Krillin on the bank and Popo and Roshi on the carpet.

"Don't expect me to save you."

He flies above the trees and disappears over the ridge.

Goshin stays facing the ridge until Goku puts a hand on his shoulder. Only then does he turn back toward his mother.

Across the ridge, Piccolo lands among the stones. He touches the place on his chest where Goshin struck him, then lets his hand fall.

"Goku's recovered. Both boys are with him."

He faces a tall rock pillar and raises his new arm. Light gathers in his palm, and the shot cuts through the stone. The upper half crashes into the ravine.

Piccolo looks at the broken end.

"The Saiyans are stronger than Raditz. I need more than that."

He sets his feet and begins again.

---

## Three Beans

Chi-Chi kneels in front of the boys. Her hands shake as she sets the first-aid box on the carpet.

"You were taken away," she says. "Turtle told me."

Gohan presses against her. "Goshin couldn't wake up. I stayed with him."

"He was there when I woke up," Goshin says.

Chi-Chi holds them both for a moment. "Turtle didn't know where that man had taken you. I didn't know if I'd see you again."

Goku rests his hand on her shoulder. Goshin watches them, then touches Goku's wrist.

"What is it?" Goku asks.

Goshin looks at Chi-Chi. "When did you know?"

"Turtle told me after you left the island. I came as soon as I could."

"I didn't know if you knew."

"You don't have to worry about telling me now. I'm here."

She draws back to look at him. His hands go behind his back.

"Show me your hand."

"Show me your hand."

He brings the bandaged palm forward. Chi-Chi unwraps the dirty cloth. New pink skin covers the middle of the burn, though the edge is still red.

"It was bleeding at the crater," Gohan says.

Chi-Chi turns the hand toward the light. Goshin spreads his fingers for her. She takes a clean dressing from the box and wraps it loosely to keep the palm clean.

"Your head too?"

"It hurt where Raditz hit me. It stopped by the river."

"Were you sick? Did the ground move?"

"No."

She looks at Krillin. "How long was he unconscious?"

"Raditz knocked him out on the island. He was awake when we reached the crater. I don't know exactly how long."

Chi-Chi closes the box. "I'm having someone look at him today. A blow that knocked him out isn't something I'm guessing about."

Goku nods. "We'll take him."

Krillin offers Goshin the second bean. "This would heal your hand and your head."

Goshin looks at it. "Did you watch it being made?"

"No. Korin took it from a jar."

Goshin steps back. "I didn't see."

Krillin draws his hand away. "All right."

"Can I see where Korin makes them?" Goshin asks.

"We can ask him," Krillin says. "I don't know how long it takes."

Chi-Chi brushes the hair back from Goshin's cheek. "For now, I want you close enough that I can see you."

"For now, I want you close enough that I can see you."

Goshin sits beside her on the carpet.

Krillin holds out the bean to Gohan. Gohan looks at his brother.

"There were three," Krillin says. "Your father had one. If you take this one, we'll still have one left."

Gohan takes it and eats it. He raises his arm, then turns it all the way around.

"It doesn't hurt."

"And your strength?" Chi-Chi asks.

Gohan gets up. "That's back too."

Goku grins at him. "Good."

Goshin watches Gohan move his shoulder, then looks at the remaining bean. Goku notices.

"What is it?" he asks.

"Gohan got better all at once."

Goku looks at Goshin's newly wrapped hand. "Yours is getting better too."

"I still want to see where Korin makes them."

Goku puts an arm around him. "We'll ask."

"I'll go with you to ask Korin," Gohan says.

"You don't have to."

"I want to."

Goshin leans against Gohan. Krillin ties the bag shut and puts it away.

"I'll keep it safe," he says.

---

## Above the Clouds

Popo lifts the carpet from the bank with the family and Roshi aboard. Roshi keeps the medical case beside him, and Krillin flies alongside as Popo carries them back toward the clearing.

When the damaged aircraft appears below them, Bulma waves from its tail.

"They're together," Popo says.

He brings the carpet down. Goku steps off first and turns to help Chi-Chi and the boys. Chi-Chi takes her first-aid box with her. Goshin waits until Goku offers his hand before he lets his father lift him down.

"The rod's bent," Bulma says. "I can mend it, but not in one minute."

"You don't have to," Goku says. "We can get everyone home."

Popo looks toward the clouds. "I should tell Kami what happened."

"Thank you for finding us," Goku says.

Popo bows his head and lifts away on the carpet.

At the Lookout, Kami is waiting with his staff. Popo lands beside him.

"The boys reached Goku," Popo says. "Piccolo tried to take them. He left when the others came."

"He still intends to rule this world," Kami says.

"He also stopped an animal from reaching the boys."

Kami looks down through the clouds. "That is not the same as letting them choose."

"You spoke to King Yemma?"

"Raditz reached his judgment. In the past, souls killed by the Demon Clan wandered without finding rest. Raditz did not. Something about Piccolo is different."

"Does that mean he is good?"

"I don't know. We have seen what he did to the children."

Kami rests both hands on his staff.

"There is something else. I have a feeling my life may have about a year left."

Popo turns toward him. "Because the Saiyans are coming?"

"Perhaps. Or it may be my own age. I cannot tell, and I may be wrong."

"If Piccolo dies, you die too."

"And if I die, so does he. Our lives are joined. If my feeling is right, the Dragon Balls may have only one use left."

Kami looks toward the world below. "Perhaps Piccolo feels it too. Perhaps he wants to leave something behind, even if it's strength in Goku's sons."

"That doesn't excuse what he did."

"No. It doesn't."

Popo looks toward the clouds. "The others should know."

"They should. I'll speak to Goku."

Kami lifts his staff and walks toward the edge of the Lookout.

---

## A Cup of Tea

In Otherworld, a customer orders French toast and milk. At the café counter, another customer counts her change.

"One coin short."

The server finds it beneath a saucer. At the next table, Fortuneteller Baba watches the coin change hands, then turns to the guide opposite her.

"You said Earth's guardian came to Yemma?"

"He asked whether King Kai might help a living fighter named Son Goku. His Majesty said he would ask."

"Did he give permission?"

"No. I heard him say he couldn't promise an answer."

Baba sets down her cup. "Goku is my brother's pupil. Roshi should hear that Kami asked about him."

"Please tell him exactly that."

"I'm old, not deaf."

She puts a coin on the table and climbs onto her crystal ball.

"Where are you going?" the guide asks.

"To find my brother. Someone has to pay attention down there."

The crystal ball rises past the counter. The server catches a cup before it tips.

---

## The Way Back

Gohan sits beside Chi-Chi at the edge of the clearing. Goshin sits on her other side and rests his wrapped hand in his lap.

"A little dinosaur was caught under a rock," Gohan says.

"The big one wanted to eat us," Goshin adds.

"It wanted its baby," Gohan says.

"It wanted to eat us too."

Chi-Chi looks from one to the other. "You helped it?"

Gohan nods. "The rock might have fallen when the cliff broke. We couldn't leave it there."

Goku sits beside them. "You got away from Piccolo and helped it. You did things I didn't know you could do."

"I was scared," Gohan says.

"I would have been too."

"He stopped the big one from biting us," Gohan says.

Chi-Chi looks toward the ridge where Piccolo disappeared. "After he shot at you?"

"Yes."

Goku looks at Goshin. "Did he leave you alone afterward?"

"He still tried to take us."

Goku's smile fades. "I'm sorry he got near you again."

Goshin watches him. Goku opens his arm, and Goshin leans against him.

"Can I still study if we have to train?" Gohan asks.

"Of course you can," Chi-Chi says. "You're not giving up your books."

Goku rests a hand on Goshin's shoulder and closes his eyes for a moment. "Your ki feels stronger than it did at the crater."

Goshin looks at his palm. "Even after all that?"

"Even after all that."

Gohan straightens. "What about mine?"

"It's growing too." Goku grins. "We'll all keep getting stronger."

Goku looks at Goshin. "Is there something you want to practice?"

"Aiming," Goshin says. "I want to hit the right place even when everything's moving."

"That's a good thing to practice," Goku says.

"I want Mother's curry," Gohan says.

"You just ate a Senzu," Krillin says.

Gohan puts a hand on his stomach. "Oh. I'm not hungry now."

Goku looks surprised too. "Neither am I."

Bulma stops working and stares at him. "Someone write that down."

Chi-Chi laughs, and Gohan laughs with her. Goshin smiles, then tucks his head against Goku's arm.

Roshi sets down the medical case. "There's something I should have told you on the island. Raditz spoke about the full moon."

Goku looks at him. "He said Saiyans change."

"I saw you look at a full moon during a tournament. You became a giant ape. You didn't remember afterward."

Goku's hand stops on Goshin's shoulder. "That was me?"

"Yes."

"Grandpa used to warn me about the full moon. He died, and I thought a monster had killed him." Goku looks at Roshi. "Could it have been me?"

"I wasn't there," Roshi says. "I don't know. I should have told you what I saw at the tournament. I'm sorry."

Goku looks down at his hands. Chi-Chi reaches across the boys and takes one of them.

"You were a child," she says. "And you don't know what happened."

"He warned me."

"He loved you, Goku."

Goku holds her hand. After a moment he looks up at Roshi again.

Chi-Chi draws the boys closer. "Could it happen to them?"

"I can't say for certain. They have tails. Until we know more, don't let them look at a full moon."

Gohan's tail curls around his ankle. "Are we monsters?"

"No," Chi-Chi says. "You're my sons."

"What if I look by accident?"

"We'll make sure you know when it's dangerous," Goku says. "You don't have to work it out alone."

Gohan leans against Chi-Chi. She keeps one arm around him and her other hand in Goku's.

She kisses the top of Gohan's head, then waits until Goshin lifts his face before she kisses him too.

Bulma puts the damaged rod in her toolkit and closes it. She presses the aircraft's capsule switch; the vehicle contracts into its capsule, which she slips into her case. The scouter remains wrapped in her pocket, with its cell separate.

"I can work on both of them at home," she says. "For tonight, let's get out of the forest."

Goku holds his arms out to Goshin. "Want me to carry you?"

"Yes."

Goku lifts him carefully. Gohan takes his mother's hand. Behind them, Nimbus waits above the grass.

---

## Preview

*A yellow cloud rises above the river. At the Lookout, Kami steps toward the edge with his staff. Far away, a crystal ball carries Baba toward Earth.*

**NARRATOR:** Goku and his family are together again, but Piccolo is still at large and two Saiyans are on their way. What will Kami tell them? And can Bulma learn to use the alien device without alerting its owners?
