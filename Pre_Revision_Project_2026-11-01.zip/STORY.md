# STORY — the world, the people, the scale

**Owns: the laws of the world, the clock, who is where now, how the cast sounds, and every number.**

---

## 1 · The laws

1. **Canon is the floor, not a track.** There is no parallel line to keep in step. He lives inside canon's world and changes it by being in it.
2. **Anime governs; manga corroborates.** Where they disagree, a ruling decides. **Never averaged** — a blend exists in neither source.
3. **Continuity:** DB + Z + Super + all films. Films need a verdict each (`OPEN-6`); the opening arcs touch none.
4. **He is native.** No foreknowledge, no meta-knowledge, ever. *(Declared exception to house rule F0.)*
5. **The OC changes every scene he is in.** If a scene would read the same without him, cut him or cut the scene.
6. **Never restamp an accepted hash.** An accepted chapter is corrected by a dated note, not a rewrite.
7. **Goshin is never less capable than Gohan** (O056). Gohan also grows and retains agency. There is one divergent story, not a parallel track; do not force canon beats or a ceiling against Nappa.
8. **The gate.** He cannot take Super Saiyan God **as a form.** The ritual would adapt into a divine Talent and promote his baseline, with no way back down (`STATUS §12`, O031, O032). **Late, once, one direction — and the base afterwards is what he is.**
9. **The ladder is a floor, not a staircase.** Super Saiyan 1–3 are perfected, so they are never announced; **Rage** is his, **Super Saiyan 4** is earned at the ape, and **Blue is impossible** — and because the Talent **never lets a thing be lost** (`O041`), **every golden rung he reaches for comes back divine** — God 1, 2, 3, each louder than the last — crowned by **GOD 4**, the god worn inside the ape's body (`STATUS §13`).
10. **The promotion is total, and it subtracts nothing.** The Talent becomes divine and works on everything (`STATUS §14`): his forms, his techniques and **his children** — born divine, not mortal. **And he loses nothing** — temper, appetite, jokes, grief, mistakes. Canon's god form calms a Saiyan (C119); **his does not, because nothing is taken.** (`O042`–`O044`)
11. **The era lock.** At four, and through the Z-era arcs, **he is mortal and ordinary** (`O045`). The ladder in `STATUS §13` is a **locked ceiling**: no golden hair, no god ki, no divine anything. **Writing him as anything more is a period error, not a power-up.**
12. **Canon where canon speaks; ours where it does not — and ours says so.** Every rung canon printed is played by canon's rules. Every rung it did not print is declared in `STATUS`, with the mark that it is ours.
13. **The current abduction correction.** The user rules that Raditz cannot take Goshin conscious in this encounter. His ~400 is a snapshot and his output can rise in anger; he must fight and be knocked unconscious before Raditz carries him (`O080`). This is not a general equation between battle powers or an assertion of invulnerability.
14. **Master what he has first.** In deliberate training Goshin works toward mastering or perfecting the abilities he already has before pursuing new ones. The user clarified that instinctive copying in an emergency is still allowed; the priority concerns training choices, not a ban on protecting someone (`O104`).
15. **The foundation is serious work.** Goshin gives sustained attention to basics such as stance, balance, movement, guard, conditioning, breathing and ki control, as relevant to his skills and age. Show the practice and progress; do not replace his existing strength or rapid adaptation with a forced remedial stage (`O105`).

---

## 2 · Names

- **Human: Son Goshin** (悟心) — carries the 悟 his brother carries.
- **Saiyan: Broc** — same root-vegetable register as Kakarot, Raditz, Vegeta.
- **Who says what:** the house says Goshin from birth. **Broc is first spoken by Raditz on the island.** In the provisional Chapter Four, Goshin asserts his own name. Chi-Chi has not been shown hearing or rejecting Raditz's name; the older promise that she does so in Chapter Three was incorrect.

---

## 3 · The clock — two days

**The date: 12 October, Age 761** (Daizenshuu 7 via W-23). **Mid-autumn.** The guidebook assigned it working backwards from later anchors, so it is a date of record rather than a line of dialogue — and it is the first date this serial has ever had.

**Day one (ep. 1), on the mountain** — times of day in this table are authored scheduling, not spoken timestamps.

| Hour | Mountain | Elsewhere |
|---|---|---|
| morning | Chi-Chi calls two names from the yard; Goku fells a tree and carries it up the slope with a boy on it | — |
| morning | he comes in, finds the boy missing and goes to fetch him; Chi-Chi says he likely cannot have gone far. **She stays.** | a farmer is read at **5** and killed |
| midday | Gohan alone: the sabertooth and the hat; visual staging is provisional | Raditz detects a signal at distance **4,880** and asks whether it is Kakarot |
| afternoon | Goku finds him; W-65 describes the river/Nimbus rescue and hat recovery, but the complete video is unchecked and the recovery is not shown in the accepted body (`C181`) | W-65 also describes a city after the rescue; the accepted chapter places its cut earlier and its detailed placement is authored (`C010`, `O061`) |
| evening | Goku takes **both** boys; the mother watches them go (authored placement) | Raditz reads Piccolo at **322**; after the encounter he detects a signal at distance **12,909** and says this time it is Kakarot; Piccolo says he shook |

**Day two (ep. 2), on the island** — the ten beats in `CANON §4`, ending past dark with both boys in the air, and an ultimatum: **about a hundred humans, killed and piled where he stands, by this time tomorrow.**

**Unchanged-anime mountain comparison (eps. 3–8):** this is a source baseline, not a promise that the twin-divergent story must reach the same later outcome. Accepted Chapter Three already dramatizes several early mountain moments; later events remain conditional on the actual fight.
| Ep. | What she is doing | What she knows |
|---|---|---|
| 3 | the cram-school homework is only half done; she sighs | nothing. She thinks they are having fun at Roshi's |
| 4 | humming, holding a returned test paper — eight hours a day paid off — wishing they would come home so Goku could see it | nothing |
| 5 | telling herself she should have gone too — and then **the Ox-King drives in with armfuls of presents calling for Gohan** | the question is in her yard and she has no answer |
| 6 | her worry running away out loud; **she rings Kame House and gets an answering machine** | **still nothing.** Krillin is being sent, and has not arrived |
| 7 | Krillin rehearses at her gate, fails to tell her and eats dinner; ep. 8 shows he stayed overnight | **still nothing.** He returns to Kame House the next morning in ep. 8; Roshi eventually tells her |
| 8 | she goes to Kame House herself, because the phone gave her nothing | **the telling.** Roshi says it in two words and she goes down. **Her husband is dead and her son is with the demon who killed him** |

In the unchanged anime, she does not reach the Raditz battlefield in eps 3–6 and is **not told in ep. 6**; Roshi tells her in ep. 8. In the corrected living-Goku Chapter Seven draft, Roshi tells her promptly from Kame House after Piccolo's crater attack. The unchanged-anime table above remains a baseline, not live continuity.

---

## 4 · Where everyone is now (Chapter Nine draft)

The user rejected conscious capture by Raditz (`O080`); Chapter Four shows an earned knockout. Chapters Five and Six change the fight, leaving Goku alive. Corrected Chapters Seven and Eight adapt episodes 6–7, and Chapter Nine adapts episode 8 from their ending (`canon/SCENE_COVERAGE_006.md`–`canon/SCENE_COVERAGE_008.md`). **Chapters Four–Nine remain drafts pending review.**

| | State at the end of the Chapter Nine draft |
|---|---|
| **Goshin** | At the mountain home with his parents, brother and Ox-King. He refused the third Senzu because he did not watch it being made; Roshi retains it. Goshin watches the meals he eats being prepared. His head hurts less and his burned hand is re-dressed, but the doctor has not declared him fully recovered: monitoring and another follow-up remain; hard exercise, sparring and flight practice are prohibited. She permits only gentle walking and a few foot placements. He makes several controlled placements, corrects his heel and rests. Full practice of his already-known wave and foundations waits for clearance; no new technique or perfected mastery is asserted (`O118`, `O120`). |
| **Gohan** | At home, completely healed and fully restored by the Senzu he ate. He keeps the Four-Star Ball on his hat, retains his tail, solves a small bird rescue and chooses a short supervised escape-and-call exercise. His wish to study remains his own. He and Goshin rode Nimbus to the mainland together; independent flight for him is not established (`O118`, `O119`, `O121`). |
| **Goku** | Alive at home, completely healed and fully restored by his Senzu. Kami invites him to discuss the Saiyans, Piccolo, the Dragon Balls and the possible King Kai inquiry. Goku wants to hear more but has not agreed to leave or obtained Yemma's permission. He and Chi-Chi insist on a plan for both boys, including the danger from Piccolo. He asks Baba to pass his uncertain Grandpa question; no answer has arrived (`O114`–`O116`). |
| **Chi-Chi and Ox-King** | Chi-Chi continues watching Goshin and arranges another medical check; she and Goku cover the home windows at night. Yajirobe carried Ox-King to the ninth road marker, where the truck was recovered; the family returned home with Goku alongside. The earlier schoolbag is brought out and the grandfather gives the boys additional gifts; carrying the bag remains undecided. No transformation, tail removal or particular moon phase has been established (`O118`, `O119`). |
| **Piccolo and Raditz** | Piccolo trains alone in the wasteland, still dangerous; he has neither child and has not been given Raditz's moon explanation without an earned source (`O121`). Raditz is dead and was judged by Yemma (`O100`). |
| **Roshi and Turtle** | At Kame House when the family leaves; Roshi keeps the unused third Senzu. No one has eaten it (`O118`, `O120`). |
| **Bulma** | At her laboratory with the Dragon Radar. She changed the scouter's display and tested it briefly on an external supply in a mesh enclosure after disconnecting a suspected transmitter and microphone. She cannot guarantee containment of unknown alien transmissions or the measurement's accuracy. The device is off, its original cell remains separate, and no field-safe clearance exists (`O117`). |
| **Krillin** | Left Bulma's lab intending to ask at the city stadium about Yamcha, whose baseball work she saw mentioned in a sports report. He has not yet found or recruited Yamcha, Tien or Chiaotzu. The authored enclosure test gave a momentary **206**, matching the episode-8 caption reading; his display rose when he raised energy. It is not a permanent ranking (`C124`, `O117`). |
| **Kami, Popo and Yajirobe** | Kami sent Popo down to Korin. Yajirobe delivered an invitation for Krillin, Yamcha, Tien, Chiaotzu and himself to gather at Korin Tower for Kami's training, plus the invitation for Goku and his family to visit once Goshin can travel. Yajirobe departed the ninth marker toward the tower; his arrival is not shown. Popo was last shown at Korin Tower. No group training or child custody has begun (`O114`, `O118`). |
| **Baba and Yemma** | Baba delivered the guide's message: Yemma would consider the living Goku's case if recovered and willing, but granted no permission. She departed with the children's names and Goku's request to ask Grandpa about his death, promising to try only if she finds him—not an answer, a visit or a date (`O115`, `O116`). |
| **Dragon Balls and Saiyans** | The Three- and Six-Star Balls are in a box in the home cupboard; the Four-Star remains with Gohan's hat. The family plans to ask Kami and Korin about safer placement, but has not dispersed them or made a wish. Vegeta and Nappa are travelling after hearing the scouter; their names and exact strength are not yet known to the family (`O094`, `O119`). The one-year warning is approximate. |
| **Next** | Read the complete local episode-9 captions and make a fresh source-order inventory before adapting its robot/ruins story. Continue only from the actual family-home, doctor, scouter, recruitment, Baba and tower states. The next preview promises a book and a road, not an already-met robot. No automatic custody, six-month isolation, safe scouter, moon destruction or Otherworld access is presumed. Preserve mastery-first training, serious foundations, the emergency exception and Gohan's agency. |

The accepted Chapters One–Three remain unchanged. Chapter One's hat-recovery and source/character-design gaps, Chapter Two's heading, arrival and source-order debts, and Chapter Three's date, clock, room and place-setting ambiguities remain open. A dated Chapter Three footer supersedes its incompatible §11 overnight outcome in this draft while preserving the same unanswered call. See `OPEN-17` and `AUDIT_2026-11-01.md`; no accepted prose has been silently repaired.

---

## 5 · The cast — voice law and never-list

**GOKU** — short flat sentences; questions are sincere; no sarcasm, no explaining a feeling. Affection is *doing the task*. **Never:** boasts, withholds a discovery, uses a word he has no reason to know. *Around him power is ordinary — that is why a born-100 child stays likeable.*

**CHI-CHI** — fast and specific (times, costs, the rice, not "soon"); love arrives as a plan, fear as a rule; **she finishes her sentences.** **Never:** apologises for wanting them educated, is vague about money or time, or is written as a shouting joke. *Her plans and concern are serious, not a joke.*

**GOHAN** — polite and sensitive, but able to act decisively for people he loves; he trains, learns and grows. Do not reduce him to crying, a rage switch or his twin’s sidekick. His own choices can change with the divergence (`C151`).

**RADITZ** — contempt, entitlement and explicit threats. He explains the Saiyan mission and his ultimatum in ep. 2. He does not know about the boys before finding them; do not replace his canon dialogue with a permanently polite stranger.

**PICCOLO** — severe, direct and initially hostile, but capable of explaining a plan and later praising Gohan’s progress. Let his teaching and attachment develop through what happens; do not force him to stay unchanged throughout the arc.

**ROSHI** — an old man who has decided to be funny so he does not have to be frightened; asks the dangerous question sideways. **Never:** lectures, or states the plot.

**BULMA** — the only one who talks about herself; sharp, practical, emotional at the wrong moment. **Never:** a prize or a voice of exposition.

**KRILLIN** — brave first, sensible second. **Never:** comic relief in a scene where somebody is about to be hurt.

**GOSHIN** — a four-year-old's vocabulary doing an adult's filing. **Exact questions** (*how many days*, not *when*); **an instruction said back word for word** before he does it, once; the answer arriving **half a second late** because he was still reading the room. He watches mouths, not eyes. **He shows what he can do; he does not report it.** **Never:** *pure*, a boast, an explanation of a feeling, a word he has no reason to know, or **"Broc"**. *Design: `STATUS §1–7`. The resemblance is drawn, never fractioned (R-22).*

---

## 6 · The scale — snapshots, not a locked ladder

| Reading | Source and condition |
|---|---|
| Goshin at birth: **100** | authored initial design (O002) |
| Goshin **~400** | authored scouter snapshot on Kame House island, before Raditz takes the children (O005); not a permanent floor |
| Goshin **1,500** | authored brief Chapter Six surge, separately scanned after the earlier 1,450 Kamehameha charge (O089); not a canon number or lifetime ceiling |
| Goshin **1,450** | authored Chapter Five scouter snapshot while charging his first Kamehameha, not a resting power or fixed limit (O084, O088) |
| Krillin **206** | episode-8 captioned scouter reading, repeated in an authored limited lab test in Chapter Nine; not a permanent ranking or proof the device is accurate or transmission-safe (C124, O117) |
| **710** near the pod | original episode-3 caption context places the signal near Gohan; in the two-child draft it is not assigned to either brother (C091, O076) |
| Gohan **1,307 / 1** | episode-5 moments; 1 follows the outburst, not a lifelong resting value |
| Gohan **2,800 / over 20,000** | attack-context readings in eps 28/65; the latter is explicitly momentary |
| Piccolo / Goku **322 / 334**, then **408 / 416** | ep. 3; separate targets, after clothing changes |
| Raditz **1,500**, Nappa **4,000** | guidebook values, not readings of their every attack |
| Great Ape **×10** | Vegeta's stated battle-power multiplier in ep. 32, not a collateral formula |

Raditz says **5** and **322** in ep. 1; **4,880** and **12,909** are distances, in that order and in different scenes. The 12,909 signal is after the Piccolo encounter. Numbers in a chapter must be sourced or explicitly authored and appropriate to that moment; later readings can change. Do not invent a damage-per-point calculation.

The cloud's carrying rule is a standing background trait (`C115`, `O023`); do not restage a purity test or make a new cloud scene to prove it. The prose never uses the forbidden purity vocabulary.

---

## 7 · The Talent

Present from conception, non-sentient and native to Goshin. He learns visibly from demonstrated movements, flies, uses techniques and retains acquired skill (`O004`, `O041`). The user clarified that his first Kamehameha in Chapter Five has more raw ki than Goku's wave but less of Goku's practiced control (`O088`); an effective first use is not necessarily as polished as his father's. In training, he prioritizes mastering and perfecting what he already has and gives serious attention to fundamentals (`O104`, `O105`). This does not prevent instinctive copying in emergencies, as the user confirmed. The old blanket rule that none of his skills can ever be finished is withdrawn (`R-26`). Hybrid potential, training, experience, recovery and adaptation support continued growth; no free exact number is awarded just for looking. Fatigue, injury, suppression and distraction can interrupt performance without erasing mastery. The separately ruled late divine gate and ladder remain in `STATUS §§12–14`; no god ki occurs in the present Z-era.

---

