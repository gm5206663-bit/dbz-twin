# RULES — the gate, the pass, and what failure taught

**Owns: what "done" means.**

---

## 1 · The gate — a chapter is done when all of these are true

| # | Gate | Fails when |
|---|---|---|
| 1 | **Card** | no `ANIME BASE: ep. N`; or the chapter stops short of the episode it claims |
| 2 | **Canon** | a detail has no `C-` or `O-` row; or contradicts its row |
| 3 | **Order** | a beat is out of canon's sequence, or skipped |
| 4 | **Information** | someone knows something with no path to knowing it |
| 5 | **Name** | "Broc" appears before Raditz says it |
| 6 | **Staging** | authored material is used but not declared |
| 7 | **Y6** | a scene would read the same if he were not in it |
| 8 | **Price** | ki with no cost; a fight with no aftermath |
| 9 | **Scale** | a number not in `STORY §6`; a Talent-produced reading |
| 10 | **Style** | the band in `WRITING §2` — under-styled fails too |
| 11 | **Direction** | no named shots, even lengths, no reaction, nothing withheld |
| 12 | **Voice** | a character outside their voice law or into their never-list |

**Hard fails, no repair in the same pass:** a chapter with no card · a fact from memory · an averaged detail · "Broc" too early · a time-lapse over a pivotal beat · an OC who outranks Gohan in canon's thread.

---

## 2 · The pass

```
1. read the episode's record        CANON §4, rows in facts.json
2. write                            chapters/
3. check                            python3 tools/check.py
4. update everything that moved     STORY §4 · HISTORY · facts.json
5. reseal                           MANIFEST.sha256
```

**The unit of work is the pass, not the file.** Truth runs canon → STORY/RULES/WRITING → prose, never backwards: **a chapter may not teach canon.** If prose needs a fact no row holds, go back to the fetch.

**What must move together:**

| If this changes | These move with it |
|---|---|
| a fact row | CANON §4/§6 · the chapter that spends it · STORY §4 if it is where he is |
| a grade | the row · the chapter's card |
| a correction | CANON §7 · every file that stated it — **struck in place, with the date** |
| a ruling | OPEN.md (dated) · STORY or RULES if it is a law |
| a chapter accepted | HISTORY · STORY §4 · RULES green · reseal |

---

## 3 · The ten things failure taught

| # | Rule | Held by |
|---|---|---|
| L-01 | **A summary is not a witness.** Go to the record of the work itself. | `check_citations` — every row names a registered witness |
| L-02 | **Independence is by publisher.** Two copies are one witness. | CANON §2 groups |
| L-03 | **A tier is earned by the primary work or not at all.** | `check_evidence` — cards must declare `EVIDENCE: II` while Tier I is zero |
| L-04 | **A plan is not an arrival.** | CANON §7, R-03/R-04/R-09 |
| L-05 | **Not in the record → not in the prose**, unless declared authored. | `check_staging` — every card carries `STAGING:` |
| L-06 | **Never average.** Record the contest, rule it, keep the ruling. | CANON §5 |
| L-07 | **A change is not made until every dependent file is changed in the same pass.** | the matrix above |
| L-08 | **A citation to a row that does not exist is a broken promise.** | `check_citations` |
| L-09 | **One owner per fact, said on the file's first line.** | `check_owners` |
| L-10 | **Counts are printed, never written.** | `check.py` prints them; prose must not state them |

**Rule about rules:** every new failure gets a row here **and** a check, in the same pass. A lesson without a mechanism is a hope.
