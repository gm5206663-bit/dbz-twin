# OPEN — what only the author can decide

**Owns: the questions.** Ordered by what they block. Nothing here stops a file; several stop prose.

---

### OPEN-1 · ~~Where does the anime put Chi-Chi's at-home scenes?~~ — **ANSWERED: episodes 3, 4 and 5**
*"Chi-Chi at home wondering when Goku and Gohan would return home was exclusive to the anime"* (ep. 3). Ep. 5 gives her the scene in full — **she decides a little fun is good for Gohan after all** — and then the **Ox-King arrives with gifts, asking where Gohan is** (W-17, W-18, W-19).
**Consequence, and it is a good one:** Chapter Three's first movement is no longer invented. She is at home, she is *not yet worried enough*, she talks herself into leniency — **and then a man with an ox's horns walks into the yard asking where the boy is.**
**Also corrected:** the appearance list that settled this in Chapter Two's favour is **not exhaustive** (ep. 3 omits her while giving her a scene), so the chapter's claim has been restated as *corroboration*, not proof (`CANON §5`, `R-11`).

### OPEN-1b · ~~How does she learn?~~ — **ANSWERED: the end of episode 6, from Krillin**
She never reaches the battlefield. Bulma, Roshi and Krillin find the scene; **"Krillin must tell Chi-Chi what happened"** (W-24). The Ox-King's visit is ep. 5 and is cut from the edited dub (W-19).
**So Chapter Three runs:** ep. 5 in her yard, the Ox-King at the gate asking where the boy is — *and the answer does not exist yet, in that yard, that afternoon.* The telling is ep. 6 and belongs to Krillin, on the shore of a different chapter.

### OPEN-2 · ~~The primary pass~~ — **ANSWERED for eps 1–2: the episodes were read, not summarised**
The official Japanese closed captions for all 291 episodes are on disk (`tmp/subs/ex/`) and eps 1 and 2 have been read in full, with timestamps, into `CANON §4`. **36 rows are Tier I.** What the pass changed:
- **The scale is quiet.** Spoken in two episodes: **5**, **322**, and two distances — **4,880** and **12,909**. Goku's 334/416, Gohan's 710/1,307/1 and Raditz's 1,500 are **guidebook print** and are now labelled as such (C080).
- **Five scenes were wrong in ways no summary would ever show** — the episode's ending (the blast does nothing), the moon (Raditz raises it himself), the tail (the father says it), the disbelief (there isn't any), the break-up (she chose not to tell him). All five corrected; **R-15 to R-19** retired.
**Still owed:** eps 3–6, which are all of Chapter Three (`OPEN-8`).

### OPEN-8 · ~~Episodes 3–6, read in full~~ — **DONE. `CANON §4b`.**
The four episodes Chapter Three stands on are read end to end (31 new rows, C081–C114). What they settled, and what it changes:
- **The telling does not happen in ep. 6.** Roshi *orders* Krillin to go, Bulma says the mother will kill him, and the phone call is answered by the Kame House answering machine. **She ends ep. 6 still not knowing** (`C066`, **R-21**). Chapter Three therefore cannot end on a telling; it ends on a machine saying nobody is home.
- **The Ox-King's visit is ep. 5 and it is a question, not a comfort**: he drives in with presents calling for the boy, and she has no answer to give him (`C104`).
- **She is not worried in ep. 3 — she is worried about homework** (`C059`, `C089`), and in ep. 4 she is *happy*, holding a test paper (`C099`).
- **The one-wish rule is already law in ep. 3** (`C084`): Krillin and Roshi have each been revived once and cannot be again. That is why Krillin's fear in ep. 6 is real.
- **The scale speaks in ep. 3** — 710, 322, 334, 408, 416 — and 1,330 / 1,480 follow. "The scale is silent" was true of eps 1–2 only (`C091`, `C097`, `C102`, `R-20`).

### OPEN-14 · How high by the Saiyan battle?
The curve is law now (`STATUS §9`, `O058`): **his floor only rises, as fast as he is shown things.** So the one number that must be decided is **where he stands when Nappa lands.** Three ways, and the guards in `O059` hold whichever you pick:
1. **Ahead of his brother, level with the adults** — around Gohan's best rage and Piccolo's best attack. **Keeps every canon beat** and keeps him honest.
2. **Above the adults, below Nappa** — he can hurt Nappa and cannot end him. **Costs canon one beat** (Nappa's rampage is shorter).
3. **Unbounded** — he rises as fast as the Talent is fed. **Deletes the Saiyan arc**; not recommended.
**If you say nothing:** **option 2** — because canon's hybrid rule plus the Talent (`C142`, `O058`, `O060`) puts him above the adults, and Nappa is the wall that keeps the arc standing. The beats that matter — Piccolo's death, the father's arrival — still land.

### OPEN-13 · Goten exists
**Canon gives Goku a second son, and he is a prodigy** — born after his father's death, Super Saiyan as a small child, no teaching required (ep. 207, `C134`). **Our boy is also a second son.** The sheet cannot pretend the other one is not there.
1. **Goten as canon has him** — ours is a different kind of second son: slower, quieter, mortal; the contrast does the work.
2. **Goten exists but is not a prodigy** — the prodigy slot is ours alone. Costs the "canon where canon speaks" law and needs a declared divergence.
3. **No Goten** — the cleanest for us and the most expensive against canon.
**If you say nothing:** **option 2** — because canon's hybrid rule plus the Talent (`C142`, `O058`, `O060`) puts him above the adults, and Nappa is the wall that keeps the arc standing. The beats that matter — Piccolo's death, the father's arrival — still land. **Contrast, not replacement.**

### OPEN-12 · The moon is gone
**Piccolo destroys it in ep. 8** (C127). That closes the ape road to Super Saiyan 4 (`STATUS §13`) — the rung you ruled in now has no moon to be earned under. Three ways out, and it is your call:
1. **Restore it later** — canon has form for this (a god's act), and the moon comes back in time for the ape.
2. **The gift road after all** — *Daima*'s magic, no tail, no moon (C118): the rung survives and the "earned" quality is lost.
3. **A substitute moon** — an artificial one, or a planet with a different sky. The most expensive and the most ours.
**If you say nothing:** the ape road stays canon's (option 1), and the moon's return becomes an event worth a chapter, not a footnote.

### OPEN-11 · His children
Ruled: **they are born divine, not mortal** (`O044`). Not ruled: **who they are** — how many, when, what a divine childhood costs them, and whether any of them can be *ordinary*, which is the only interesting question about a god's child.
**If you say nothing:** they exist off-page until an arc needs them, and nothing about them is invented early.

### OPEN-10 · The Daima verdict
Law 3 lists **DB + Z + Super + all films**. *Daima* (2024–25) postdates that list — and it is where **Super Saiyan 4 became canon** (C118, W-33), which the ladder now leans on. So the ledger needs one word: **IN / OUT / SIDE**.
**If you say nothing:** *Daima* is **IN** — Toriyama wrote it, and the rung exists because of it — and the ape road stays ours, on the ground that a gift is not a trial.

### OPEN-9 · The Dragon Ball rule-book
The cloud's pure-heart rule comes from **Dragon Ball**, which this corpus does not hold (we read Z from ep. 1). One encyclopaedic group says it (**W-31**, grade C). **If you say nothing:** the rule stands as written, graded C — and it stands **on `STATUS §4`, not in a scene.** Canon made the point in *Dragon Ball*; we record it and never restage it.

### OPEN-3 · ~~The tail — keep it or lose it?~~ — **ANSWERED: he keeps it.**
The ladder settled it (`STATUS §13`): **Super Saiyan 4 is his, and in this serial it is earned on the ape road** — tail, full moon, mastery of the Golden Ape (O035). A Boy who loses his tail loses a rung. *Daima*'s road needs no tail at all, which is exactly why it is not his: **the gift costs nothing, and the ape costs him fear.**

### OPEN-4 · ~~The season and the sky of that first day~~ — **ANSWERED BY THE GUIDEBOOK: 12 October, Age 761. Autumn.**
Daizenshuu 7, via Kanzenshuu (W-23/C067). Two notes: the date was **assigned** backwards from later anchors, and the anime itself never prints it.
**Your call, and it is small:** does the prose now say *October* — a word no character would say — or keep the date in the file and let the season show only in what a body feels (cold mornings, the last of the rice)? **If you say nothing:** the second. The date is canon; the word stays out of the prose.

### OPEN-5 · ~~Three standing habits~~ — **ANSWERED: `STATUS §6`.** Designed, and yours to overrule line by line.
- **mother:** when she looks him over, his hands go behind his back — he does not know he does it
- **brother:** on any path, he takes the downhill side, and crosses behind him to get it back if the path turns
- **father:** he waits to be invited to speak, comfortably, for as long as it takes

**The same pass retired "99% Goku" as a design** and replaced it with seven sections that draw him — figure, the half-second, the repeat-it-back, movement, appetites, the three habits, and the fault (**R-22**). A percentage was standing in for all of it.

### OPEN-6 · The film register
Films are in scope (law 3). Each needs one verdict — **IN** (and at what date) / **OUT** / **SIDE**. Not urgent: the opening arcs touch no film. I will bring a table to strike through.

**One film verdict now has a load on it:** the gate (`STATUS §12`, O031) rests on **canon's** Super Saiyan God ritual (C117, W-32), which lives in *Battle of Gods* — a film. If that film is ruled **OUT** of continuity, the gate keeps its shape and loses its citation; if it is **IN**, the gate is the story's most expensive rule. Say which, when it matters.

### OPEN-7 · The Goten gate — later
Canon's third son arrives years on. Two questions will need your word before that arc: what Goshin is doing the day Goten is born, and whether his existence changes who trains whom.

---

*Closed and settled: the names · the 悟 · Chi-Chi's eyes · the scale (100 / ~400 / 1,500) · Raditz takes both boys · anime governs, manga corroborates · canon is the floor, not a track · no parallel structure · native mind.*
