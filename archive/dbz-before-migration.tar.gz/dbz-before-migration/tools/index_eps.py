#!/usr/bin/env python3
"""Build canon/episodes.json — a per-episode index of the 291 official captions.
Reads the caption corpus the same way the chapters' sourcing requires: sound-only text."""
import re, json, glob, pathlib, os, collections

SRC = os.environ.get("DBZ_SUBS", "/home/user/tmp/subs/ex")
OUT = pathlib.Path(__file__).resolve().parents[1] / "canon" / "episodes.json"

TERMS = {
    "moon": r"満月|月が|お月|月を",
    "tail": r"尻尾|しっぽ",
    "god": r"神様|神と|界王神|大魔王|創造神",
    "ssj": r"超サイヤ人",
    "revive": r"生き返|復活|ドラゴンボール",
    "dead": r"死ん|死ぬ|殺され",
    "train": r"修行|特訓|稽古",
    "kai": r"界王様|カイオウ",
    "freeza": r"フリーザ",
    "cell": r"セル",
    "buu": r"魔人ブウ|ブウ",
    "gohan": r"悟飯",
    "study": r"塾|勉強|宿題",
    "power": r"強さ|戦闘力|パワー",
}

def parse(p):
    t = pathlib.Path(p).read_text(encoding="utf-8-sig", errors="replace")
    out = []
    for blk in re.split(r"\n\s*\n", t):
        L = [l.strip() for l in blk.splitlines() if l.strip()]
        if not L: continue
        i = 1 if L[0].isdigit() else 0
        if i < len(L) and "-->" in L[i]:
            ts = L[i].split("-->")[0].strip().replace(",", ".")
            h, m, s = ts.split(":"); t0 = int(h) * 60 + int(m) + float(s) / 60
            out.append((t0, re.sub(r"<[^>]+>", "", " ".join(L[i+1:]))))
    return out

def main():
    eps = []
    for f in sorted(glob.glob(f"{SRC}/Dragon_Ball_Z_*.srt")):
        n = int(re.search(r"_(\d{3})\.srt", f).group(1))
        lines = parse(f)
        body = [(t, x) for t, x in lines if not x.startswith("♬") and t < 26]
        spk = collections.Counter(m.group(1) for x in body for m in [re.match(r"[（(]([^)）]{1,8})[)）]", x[1])] if m)
        narr = [f"{int(t):02d}:{int(t%1*60):02d} {x}" for t, x in body if "ナレーション" in x or x.startswith("〈")]
        prev = [f"{int(t):02d}:{int(t%1*60):02d} {x}" for t, x in body if t > 23.5]
        hits = {k: [round(t, 1) for t, x in body if re.search(v, x)] for k, v in TERMS.items()}
        eps.append({"ep": n, "lines": len(body), "last": round(body[-1][0], 1) if body else 0,
                    "speakers": [s for s, _ in spk.most_common(8)],
                    "narration": narr[:4], "preview": prev[:4],
                    "hits": {k: v[:12] for k, v in hits.items() if v}})
    OUT.write_text(json.dumps({"source": "official Japanese closed captions (kitsunekko), read sound-only",
                               "count": len(eps), "eps": eps}, ensure_ascii=False, indent=0) + "\n")
    print(f"{len(eps)} episodes indexed → {OUT}")

if __name__ == "__main__":
    main()
