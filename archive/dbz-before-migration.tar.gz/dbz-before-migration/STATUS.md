# STATUS — the boy, designed

**Owns: the design, the standing, and the era.** Who he is at four: figure, face, speech, movement, appetites, faults, habits — then the biology, the scale, the traits canon certifies, the traits we declare, and what none of it is allowed to mean.

**The rule of this file:** **a resemblance is drawn, never fractioned.** "99% Goku" is **retired** — a casting note, not a design: it tells nobody what he does with his hands, what he asks, or what he is afraid of. Everything below is a thing a camera can see or an ear can hear.

**THE ERA LOCK — read this before anything else.** **As of Chapter Three he is four years old and he is nothing but a boy.** Mortal. One tail. No transformation, no golden hair, no god ki, no divine anything — **the entire ladder in §13 is a ceiling documented for a much later era, and it is locked.** In the Z-era he does what the others do: he eats, he trains badly, he is carried, he is left behind, he cries, and once in a while he does something that frightens an adult. **Everything from §12 down is FUTURE.** (`O045`)

**Where this file and a chapter disagree, this file is right and the chapter is rewritten.** Canon that has already explained something is **recorded** here, never restaged in prose.

---

## 1 · The figure — what the camera sees

| | |
|---|---|
| build | his twin's height, and a head heavier through the shoulders — the difference is visible only side by side |
| stance | weight on one leg, always the same leg; the other is a spare |
| hands | never empty. A stick, a stone, a nail, the hem of a sleeve. In a fight, empty and still |
| stillness | **he is the only child in a room who is not moving.** Adults read it as good behaviour; it is attention |
| when he is idle | he fidgets — taps, turns things over, takes a thing apart with his fingers |
| when it is dangerous | the fidgeting stops. That is the tell, and nobody in his family has learned to read it yet |
| face | his father's jaw and his father's hair; **his mother's eyes** — that is the whole of the 1% |
| scars | none. Not yet |

---

## 2 · The face, and the half-second

**He watches mouths, not eyes.** When somebody talks to him he looks at how the words are made. It is not rudeness and it is not affection; it is a boy copying a machine he intends to run.

**The lag.** His face arrives **half a second after the room.** A joke lands, everyone laughs, and *then* his face does it — because he was still reading whether it was a joke. It is the single most useful thing about him on a page: it lets the narrator show him thinking without ever entering his head.

**When he decides something,** he does not nod. He looks away first, and then back, and then he does it.

---

## 3 · Speech — the repeat-it-back

- **He asks exact questions.** Not *when?* but *how many days?* Not *where?* but *which ridge?* A four-year-old's vocabulary doing an adult's filing.
- **He says an instruction back, word for word, before he does it.** He got this from his mother, who does it to his father in the kitchen — *"Say it back to me."* He has never been told to do it. He watched it done, and it works, so it is his.
- **Then he does it once.** Exactly once, exactly as said, and if it was said wrong he does it wrong and does not argue.
- **He never reports what he can do.** The deed is on the page or it did not happen. He does not narrate himself, and he does not say *watch this.*
- **Vocabulary of four.** The exception, always, is **timing** — the pause before an answer, the answer arriving late and complete.
- **He does not lie.** He also does not volunteer. Asked a question he does not want, he says something true about something else.
- **Never in his mouth:** *pure* · a boast · an explanation of a feeling · **"Broc"** · any word he has no reason to know.

---

## 4 · Movement and nerves

- **He copies posture without meaning to.** Sit like a person and he will be sitting like them in a minute. Stand like one and he will stand like that. It is not mockery and he cannot switch it off. **This is the human half of the Talent** — the same machinery that lets him master a technique after seeing it has him walking like a stranger because the stranger walked interestingly.
- **He stands still to think.** He never paces. The stillness is the working.
- **The louder the room, the quieter he gets.** Not sullen — *concentrating*. In noise he is at his most dangerous and looks at his calmest.

---

## 5 · Appetites, and the one refusal

| | |
|---|---|
| eats | like his father; eats *everything*, and fast, and asks for the pot |
| the exception | **he will not eat anything he has not watched being made.** Not a preference — a rule of his own that he cannot explain and will not break. It is the same instinct as the copying: he trusts what he has seen with his own eyes, and nothing else |
| loves | being carried · being told the plan · the smell of the fire · an adult who answers a question properly |
| will not have | being **lifted without warning** · a stranger's hand on his head |

---

## 6 · The three habits — discipline with no caption

- **with his mother:** when she looks him over, **his hands go behind his back.** He does not know he does it. She has never asked him to.
- **with his brother:** on any path, **he takes the downhill side.** Every time, without being asked, and if the path turns he crosses behind him to get it back.
- **with his father:** **he waits to be invited to speak.** He will stand at the edge of a conversation for a quarter of an hour, entirely comfortable, and answer the moment he is asked — never before.

---

## 7 · The fault, and the fear

**The rage is cold.** Canon's Gohan screams and erupts; this one **goes quiet.** The noise drains out of him, the fidgeting stops, and then it is done and it is over. **The 1,500 belongs to a silent boy** — which is why nobody sees it coming twice.

**What he is actually afraid of.** Not pain — he is a Saiyan child and pain is weather. Not the dark. **He is afraid of being the second to know.** Being told *after* is the thing that makes him small: after the decision, after the visitors, after the bad news. It is the fault that will generate scenes for a hundred chapters, and it is the one his mother hands down to him without either of them noticing.

---

## 8 · Biology

| | |
|---|---|
| species | half-Saiyan; the two genetics **fuse cleanly** (O003) |
| the tail's use | with the tail and a full moon, **×10 base** (C068, C029) |
| **the moon** | **Piccolo destroys it in ep. 8** (C127), on the night the other boy first turns. **No full moon exists after that**, which is why the ape road to Super Saiyan 4 needs a ruling (`OPEN-12`, O046) |
| his tail | **one, at four, kept** (C007, C016, C036) |
| the tail's cost | grip a Saiyan's tail and the strength drains out (C083) — a weakness he carries as long as he carries it |
| growth | what nearly kills him makes him stronger. **A slope, never a quoted number** |
| what he is not | not a technician. He is fast to **grasp** (R10) |

---

## 9 · The curve — 400 is a floor, not a level

**The error in this section, named:** it printed a reading and let it read as a standing level. **400 is what the instrument said in the first week of the training year.** It is not what he is.

| point | reading | whose |
|---|---|---|
| born, at rest | **100**, fully stable | ours (O002) |
| four, at rest, **first weeks** | **~400** — **a floor** | ours (O005) |
| four, the first time it goes | **1,500** — the reading of the man who took him | ours (O002, C053) |
| afterwards | **upward only. There is no row under 400 again.** | ours (O058) |
| beside him | Raditz **1,500** · Gohan **710 / 1,307 / 1** · Goku **334 / 408 / 416** · Piccolo **322** | canon's (C080, C091, C100) |

**The growth law, in three parts (`O058`).**

1. **He is a Saiyan, and canon's engine is a body that rises.** Goku reads **416** on the day Raditz lands and is fighting at **seven to eight thousand** by Nappa (ep. 28, `C130`) — off one year of a dead man's training on a small planet. **That engine is the baseline, not a bonus.**
2. **The Talent is applied to that engine, and it does what it always does: it makes native what it adapts to.** So **nothing gained is lost** (`O041`). Goku's year is a climb with slips and strain; **his is a climb with no descent.** The Talent does not add power (`O004`) — **it deletes the falling back.**
3. **Growth needs exposure.** The Talent adapts to what it is *shown*. A year with a demon who refuses to teach him anything for six months is a year of the wrong kind of exposure: **he gets harder, not bigger** (`O057`). **His curve is not a rate. It is a response.**

4. **And his class is canon's own highest-potential class, in canon's own words.** Vegeta, ep. 5: our blood mixed with Earthlings 「強力なパワーを持つ 雑種」 — **and then the sentence that matters**: 「そんなやつらが**成長して さらに力をつけていってみろ**」 — *let them grow and keep gaining, and it is our position that is in danger* (`C142`). **Canon does not merely permit a hybrid's climb; canon is frightened of it.** So the curve is not an indulgence: **he is a hybrid, which is growth, with the Talent on top, which is no descent.** The consequence is a clean one — **at any given age he leads every hybrid of that age** (`O060`).

**The formula, written plainly.** *What he can do is a floor that only rises, rising as fast as he is shown things — and he is never shown more than the year gives him.*

**And three guards, so the growth does not eat the story (`O059`).**

- **He may never be stronger than a canon fighter's printed number at the moment canon needs that fighter.** Canon's numbers are the load-bearing walls.
- **He is ahead of his brother and above canon's adults, but never above the plot's monsters.** That is `§16` and `OPEN-14`'s default: **at the Saiyan battle he is above Piccolo and above Gohan, and below Nappa** — **Nappa is the wall that keeps the arc standing.** The order at every arc: **him · his brother · canon's adults · the monster.**
- **A beat canon needs does not stop happening because he is strong.** He can be stronger and still arrive late, still be carried, still be the one told to stay behind. **Strength has never once decided who the story is about.**

**And the bill does not change with the curve.** The damage still comes from the body's currency and from feats (`WRITING §16`), **not from the reading** — which is why a rising number does not license a bigger hole in a hill. **It licenses a heavier push, a deeper trench, a further throw.**

---

## 10 · Certified — canon says it, we only record it

| Trait | Standing | Witness | Grade |
|---|---|---|---|
| **pure of heart** | the cloud carries him. Canon settled the test in *Dragon Ball*: the Nimbus holds only the pure and drops everyone else. **Recorded here; never staged again** | C115 · O023 | C / D |
| **the half that is not Saiyan** | the Earth half is no dilution: Raditz calls a half-breed's power abnormal, and Vegeta wonders if it is the beginning of something | C100 · C103 | A |
| **the wish-rule binds him** | Shenron cannot grant the same wish twice; revivals are **spent once**. Law for everyone — which is why no death in this serial is cheap | C084 | A |

---

## 11 · Declared — ours, by your ruling (R10)

| | |
|---|---|
| born at 100, **fully stable** | the base does not wobble; the rage does |
| **the father's shape, the mother's eyes** | see §1–§2. This is the design; the percentage was a shortcut and is retired as prose (R-22) |
| **comfortable as a Great Ape** | when it comes he is not frightened of it — the family's problem, not his |
| **higher battle IQ** | reads a fight faster than his father did at four |
| **emotional** | it is the fuel *and* the flaw; the number that proves it is **1,500** |
| **loves it** | the going, the noise, the after |
| **masters after seeing** | once, watched properly, and then it is his — see §4 for what that costs him socially |
| **the Adaptation Talent** | refines ki, **never raises battle power** (R7, R17, O004) |

---

## 12 · The gate — the one thing he cannot have

**He cannot achieve Super Saiyan God as a form. There is no form for him.**

Canon's god state is made by a **ritual** — five righteous Saiyans and the one who receives, hands joined, ki poured in — and its own legend is that it **runs out of time** (C117). That time limit is the whole shape of it: a mortal borrows godhood and gives it back.

**His Talent does not give it back.** Godly ki is not a bigger version of what he already has — it is a different substrate — and the Talent's one talent is that it **makes native what it adapts to**. So the ritual would not hand him a transformation. It would adapt, become a **divine** talent, and promote his **baseline**. **His base form would become Super Saiyan God** — permanently, at rest, with nothing to switch off.

| | ordinary ki | godly ki |
|---|---|---|
| what it is | an amplification of his base | a different substrate |
| what he can do with it | **enter and leave it** — the Talent makes it cheap and quick | **nothing. He can only become it** |
| the result of the ritual | — | **no transformation, no time limit, no way down** |

**It is a door, and it opens once, late.** Canon's god state is a *mortal's* form; his would be a *promotion*, and a promotion cannot be undone. So the gate is a **timing rule**, not a ban: **no god ki in the arcs we are writing** — and when the serial finally reaches that era, the crossing is **one event, one direction, and the end of his mortality.** **It is not the end of him** (§14). After it, **Super Saiyan God is not a form he takes. It is his base** (§13). **Write the refusal for a hundred chapters. Write the crossing once, and never write it as a power-up** — and never write it as a loss of self (§14).

**Why it bites, specifically:** the ritual wants the **righteous**, and he is the most certified heart on the planet (C115, §10). He is *exactly* who they would ask. **The pure-hearted child is the one who must say no** — and his fault is that he cannot bear to be left out of anything (§7). Being left out of this is the mercy, and he will not be able to see it that way.

**What it does not touch:** his own line — Super Saiyan and whatever he earns above it — is ordinary ki, and he enters and leaves it like anyone else. **Ultra Instinct is a different mechanic** (a state earned by the body, not ki borrowed from gods) and is **not** ruled on here. Slots stay slots.

---

## 13 · The ladder — what he uses, and what he never will

**Two roads, and he walks both — because he builds the second one himself.** Canon hands Saiyans a golden ladder: 1, 2, 3, god, then **Blue** by wearing the first on borrowed god ki. **He cannot take that road** (`§13` below) — so from a divine base and an ape's body he **makes his own rungs**, and the top of it is a form canon has never handed anybody.

| rung | what it is | what it costs him | era |
|---|---|---|---|
| **the ordinary body** | a four-year-old with a tail | everything, for a hundred chapters | **NOW — this is all he is** |
| **Super Saiyan 1 · 2 · 3** | **finished.** Perfected, internal, never announced (O033) | nothing — engine, not gear | **locked.** He has not transformed once on the page |
| **Super Saiyan Rage** | his signature. Anger made cold (O034) | he can be cruel in it, and remembers it | **locked.** It arrives the first time he is hurt badly enough |
| **Super Saiyan 4** | his **physical apex** — fur, red, the wild body. Earned on the ape road (O035) | fear, paid in advance, at the moon | **locked.** Far. Years of story away |
| **── the crossing ──** | the ritual, once, late (`§12`) | the **mortal** — not the boy | **locked** |
| **Super Saiyan God** | **his base.** Not a form — what he *is* (O037) | nothing. It is only a floor | **locked** |
| **God 1 · God 2 · God 3** | **the same three rungs, converted** — reach for gold, arrive divine (O038) | **each rung leaks.** He gets *louder* | **locked** |
| **Super Saiyan 4 over god** | the ape body wearing the divine base | — | **locked** |
| **GOD 4 — the ultimate** | **the fusion:** god worn inside the SS 4 body. His Ultra class — **instinct when calm, ego when not** (O039) | **silent, and slow to arrive** | **locked** |
| **Super Saiyan Blue** | **never** (O036) | — | **never** |

**Why 1, 2 and 3 are not in his mouth.** A form you have finished is not a **gear you shift**; it is part of the engine. Perfected, they cost him nothing and announce nothing. **No hair, no lightning, no counting out loud, no "and this… is to go further."** The power is simply present, and the page proves it by what he breaks.

**Why Rage is his.** Canon's vocabulary, our mechanism: the anger is **cold** (`§7`). Not a bigger version of him — the quietest one. The 1,500 belongs to it.

**Why Super Saiyan 4 is his and nobody else's.** Canon now has two roads to it: the old one — **tail, full moon, mastery of the Golden Ape** — and *Daima*'s, which is **a gift of magic from Neva and needs no tail at all** (C118). **This serial takes the ape road, and says so:** his tail is kept (**`OPEN-3` closed**), and *comfortable as a Great Ape* has been his declared trait since R10. **The gift costs nothing. The ape costs him fear, and that is why the form is his.**

**The god rungs are conversions, not inventions.** He does not design anything. **He reaches for a golden rung, and the reach comes back divine.** Stand on a Super Saiyan God base, pull the lever marked *Super Saiyan 2* — and the Talent folds the base into the reaching, so what arrives is **God 2**: the same degree, the same shape, the same three-step feel in his hands, on a substrate that is not gold. **God 1 is what Super Saiyan 1 makes of him now. God 2 is what 2 makes of him. God 3 is what 3 makes of him.** He still has exactly three gears. They simply do not run on the old fuel.

**And that is the retention law showing its face.** The Talent **never lets a thing be lost** (O041). It refused to give godhood back, which is why his base is what it is (`§12`); and it refuses to let a golden rung *revert* him to a lesser state, which is why the gold cannot come out any more. **Nothing he has acquired is ever dropped** — not a form, not a technique, not a grudge. He can **hold back**; he cannot **un-have**.

**The scene this writes for free.** Every enemy who has ever fought a Saiyan waits for the hair. He reaches for the second rung, and the hair does not come, and something much worse does. **The expectation is the weapon.**

**And why the rungs get louder.** God ki **leaks** — canon names leakage as the flaw in the higher golden forms, and it is worse for a boy working a substrate he is inventing. Every rung up his own ladder **bleeds power into the world**: he can be sensed at God 1, tracked at God 2, and heard coming at God 3. **For a child whose whole method is silence, the climb is a confession.** He uses them as little as he can and hates them.

**GOD 4 — the crown, and the silence coming back.** Take the body that is not afraid of the ape and put the divine base *inside* it, and the leakage stops: **fur is a vessel.** The paradox of the top of his ladder is that it is **quieter than the rung below it** — a god state nobody can feel, arriving in a body built to hold one. Its character is the fusion of the two states he already owns: **when he is calm it is instinct** — the body answering before he decides, which is what a boy who copies postures has been practising since he was three; **when he is not calm it is ego** — his cold rage, feeding on itself, taking more damage and becoming more. **He does not choose which one comes up. The mood chooses.**

**It is in canon's Ultra class and it is not canon's.** Ultra Instinct and Ultra Ego are **other people's** states, and this serial does not lend them out. His is his own, reached by his own road, with the same two faces.

**Order matters.** The physical apex comes **first**, while he is still a boy with a tail. The crossing comes **late**. **God 4 is the last thing in the ladder and the only form in this serial that nobody else has a road to.**

**And none of it is happening yet.** Nine of those ten rungs are **locked**. The only rung in play is the first one, and it is a four-year-old eating rice. **A chapter that reaches up this ladder has broken the era, not the ladder.**

---

## 14 · After the crossing — everything, promoted

**The Talent itself becomes divine, and it works on everything.** That is the whole content of the crossing: not a form gained, but a **substrate changed**, permanently, in every part of him at once.

| what it touches | what happens |
|---|---|
| his ki | divine at rest. There is no ordinary setting any more |
| his forms | every rung — Rage, Super Saiyan 4, God 1·2·3, God 4 — now runs on divine qi (O042) |
| his techniques | whatever he learns from that day is learned **divine**, first time, because the substrate is what he learns on |
| **his children** | **born divine, not mortal.** His line does not start at the ritual; it starts at him (O044) |

**And nothing is subtracted. This is the ruling that matters most on the page.**

Canon's Super Saiyan God **cools a Saiyan** — the form is described as bringing a calm mind, and it is one of its listed benefits (C119). **His promotion does not do that, because the retention law does not take things away** (O041). What godhood costs other people is the thing it does not cost him:

- **He keeps his temper.** All of it. The cold rage is still cold, and it still arrives.
- **He keeps his appetite, his jokes, his grudges, his grief.** He eats like a Saiyan at a divine substrate. He cries at the same things.
- **He keeps being wrong.** A god with a four-year-old's filing system and a mother's rules, still guessing.
- **He keeps loving people who can die.** That is the one that will hurt, and it is not a power.

**The line to write by:** *the crossing makes him more, and takes nothing.* Every scene after it must be able to prove that sentence — **and any scene where godhood makes him serene, distant, or above a joke is a scene to cut.** (O043)

**What it does not do.** No Blue (`§13`). No borrowed Ultra Instinct, no Ultra Ego — his Ultra class is God 4 and it is his own. No new rungs beyond the ones already named. **And no ceiling removed:** divine substrate is a floor and a fuel, not a guarantee.

---

## 15 · What none of it may mean

- **The Talent is not a power increase.** Ever. It changes what he can do with what he has.
- **Purity is not judgement.** The cloud certifies his heart, not his aim. He can be wrong all afternoon with a clean heart — **the cloud and the scouter disagree, and both are telling the truth.**
- **No meta-knowledge** (R6). He knows what that mountain knows.
- **No terminal mastery.** Nothing he has is finished.
- **No god ki early.** Not a taste of it, not a spark, not "for a second" — until the crossing, which happens once (§12), and after which it is not a form but a floor (§13).
- **No Blue, ever.** Structural, not a convenience: no Super Saiyan 1 to wear, no borrowed god ki to wear it on (§13).
- **He never loses a thing he has learned.** Retention is the Talent's spine (O041): no regression, no forgotten technique, no form that stops working. What he loses, he was never given.
- **He never announces a rung, and the narrator never numbers one.** No "God 3". The page shows the cost — the leaking, the silence, the mood — and lets the reader count.
- **Nothing here is recited in prose.** This is a ledger. A chapter shows one line of it and says nothing about the rest.

---

## 16 · Against the other boy — he is never the lesser brother

**Canon's readings for Gohan are three numbers, and only one of them is his at rest: 710 / 1,307 / 1** (`C080`, `C091`). **The 710 and the 1,307 are bursts of rage; the 1 is the boy standing still.** Ours reads **~400 with his feet on the ground *in his first week*** and **1,500 when it goes** — **and after that his floor rises and Gohan's does not** (`§9`, `O058`). **The comparison below is the worst day of it, and it still favours him.**

| | Gohan | him |
|---|---|---|
| at rest, first weeks | **1** | **~400** — and rising, while Gohan's stays a one |
| when it goes | **710**, then **1,307** | **1,500** |
| after the burst | back to **1** | back to **a floor that is higher than the last one** — **he never falls back to nothing** (`O058`) |
| learning | taught, slowly, by a demon who shouts | **sees it once, has it, keeps it** (`O004`, `O041`) |
| what he keeps | what he practises | **everything. He can hold back; he cannot un-have** |
| first to fly | later in the year | **before him** (`O057`) |

**The ruling, and it is not a matter of taste: he is never second to Gohan where both are measured** — and by canon's own hybrid rule (`C142`, `O060`), the same holds against every hybrid of his age: **Trunks, Goten, and the one from the future.** They have the potential; **he has the potential and keeps it.** Gohan's advantage in canon is a **burst** and a **story** — he is the one the plot hands the moment to. **His ceiling is the plot's; ours is not the plot's.**

**Three mechanical reasons, and any one of them carries it.**

1. **Floor against burst.** Gohan at rest is a one. Our boy at rest is a four hundred. **A brother who is stronger only when screaming is not stronger.**
2. **The Talent deletes forgetting.** Seen-once mastery, retained forever, never converting into battle power (`O004`, `O041`). **Gohan has to practise and can regress; ours cannot regress.** In a year of training, that difference is the whole year: **he flies first, and the trick that put him on the ground once never puts him there again.**
3. **The one place canon gives Gohan more — a momentary 1,307 — is a burst *inside* the same episode that already had him at one.** Ours at 1,500 in rage **holds the higher floor underneath it.**

**And what stops him being a wish-fulfilment problem.** He is better than Gohan and **still not the hero of this story**: he is not the one the demon chose, not the one the plot is about, and **not the one the mother is waiting for in the yard.** Being the stronger brother has never once made a boy the loved one, and this serial does not pretend otherwise.

---

## 17 · Slots — still open

| | |
|---|---|
| the tail, into the later arcs | **`OPEN-3`** |
| the day Goten is born | **`OPEN-7`** |
| eps 7+ — where he is, hour by hour | unread |
| the design itself, §1–§7 | **yours to overrule line by line.** Every item is a decision, not a discovery |
| God 1 · 2 · 3 — how each rung is entered, and what each one breaks | **named, not yet written.** The rungs exist; the scenes that cost him them do not |
| the day the crossing happens | **late, and unwritten.** It is the end of one book and the beginning of another |
| his children — how many, when, and what divine birth costs them | **`OPEN-11`.** The standing is ruled; the people are not yet written |

---

*The percentage is gone. What replaced it is seven pages' worth of a boy: what his hands do, what he asks, what he copies, what he will not eat, and the one thing he is afraid of.*
