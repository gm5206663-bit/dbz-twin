# Chapter Seven — The Sky Between Them

A yellow cloud trails an aircraft above the forest. Far below, the trees bend around a narrow river.

**THE SKY BETWEEN THEM**

**NARRATOR:** Raditz is dead. Two stronger Saiyans are coming to Earth, and the fighters who stopped their brother have a year to prepare.

Inside Bulma's aircraft, Goku is still breathing. Neither of his sons has let go of his blanket.

---

## The New Arm

Piccolo lands on a shelf of rock above the forest. His left sleeve hangs empty, and the cloth pressed against his shoulder has turned dark.

He throws the cloth aside and plants his feet. The stone cracks beneath his boots.

His shoulder tightens. A new arm pushes out through the torn sleeve, and Piccolo clenches his teeth until the hand opens at its end.

He drops to one knee. For a few moments he stays there, breathing hard.

Then he flexes the new fingers.

Above the ridge comes the whine of an engine. Piccolo looks up. The aircraft is already moving away, with Nimbus following behind it.

"One can fight," he says. "The other nearly killed Raditz without knowing how."

He gets to his feet. His new arm trembles once before he closes the hand.

"A year."

Piccolo rises above the trees and follows the aircraft.

High above the clouds, Kami watches from the edge of the Lookout. Mr. Popo stands beside him.

"Goku survived," Popo says. "So did both boys."

"Thanks to all of them," Kami says. "Even Piccolo helped."

"But the other Saiyans are coming. Could Shenron stop them?"

Kami grips his staff. "I doubt the dragon could destroy fighters that powerful. They barely stopped one. I must ask whether King Kai can help them prepare."

"Piccolo is following the aircraft," Popo says.

Kami looks down toward the forest. "Keep watch while I speak to King Yemma. If Piccolo attacks them, do what you can."

Popo nods. Kami turns away from the edge, and Popo remains there, watching the aircraft below.

---

## Passengers

Roshi checks the straps holding Goku's stretcher to the cabin floor. Bulma sits at the controls ahead of them, with the forest visible through the windshield.

Gohan has his hat on again. He sits beside Goku's shoulder, watching his father's face. Goshin sits on the other side, his bandaged palm resting in his lap.

"I can still see Nimbus," Gohan says.

Goku turns his head toward the window. "He doesn't want to miss anything."

Goshin peers past Goku. "He's following the aircraft."

"He's probably hoping there's lunch in it."

Gohan looks at Goku. "Clouds don't eat."

"They don't? I thought that was why he always comes when I call."

Gohan's mouth opens. Then he sees Goku's grin.

"Father!"

Goku laughs and immediately presses his good hand to his ribs.

"Don't do that," Bulma says from the front.

"Laugh?"

"Make me turn this aircraft around."

"We just left," Roshi says.

"Then he'll have longer to think about it."

Goshin grins. His grin fades when Goku shifts on the stretcher and cannot find a comfortable position.

Bulma glances back. "Kame House first. Krillin knows to meet us there."

"Chi-Chi's going to be worried," Goku says.

"Roshi will call her. We'll explain what happened."

Goshin lifts his good hand. Goku notices him waiting.

"What is it?"

"Will Mother be angry with us?"

"Probably with me," Goku says.

"She's got enough for all three of you," Bulma says.

"She'll be glad you're safe," Roshi adds.

Gohan's fingers tighten on the blanket. "We are safe now, aren't we?"

Goku reaches toward him. Gohan takes his hand with his uninjured arm.

"We're together."

Gohan looks down at their hands. "When I hit Raditz, I didn't mean to break his armour. I just wanted him to get off you."

"You did get him off me."

"What if I'd hurt you instead?"

Goku takes a moment to answer. "I don't think you would have. But I know that was frightening."

"I couldn't stop being angry."

"You were trying to help me. You don't have to be ashamed of that."

Gohan leans against the stretcher, careful of his shoulder. Goshin watches them, then touches Goku's blanket. Goku looks across at him.

"What about you?"

"My wave went where I wanted it to go," Goshin says. "But it made a bigger hole than I wanted."

"You'd never done one before."

"Yours went straight."

"I've had a little practice."

Goshin tilts his head. "More than a little?"

"More than a little," Goku admits.

"Can you show me again when you're better?"

"Sure. We'll start with aiming."

Gohan puts his hat on the stretcher. "I'll watch."

"You can try too," Goku says.

"Maybe. But I want to finish my book first."

"Then we'll make time for that."

A shadow crosses the cabin window.

Bulma looks up. Piccolo flies alongside the aircraft.

"Oh, no."

His left arm is whole. He raises it and knocks once against the glass.

Roshi stares at the arm. "It grew back?"

Piccolo points toward the side door.

"Roshi, don't open it," Bulma says.

The latch bends. The door jerks outward, and the wind rushes in.

Roshi catches the medical case before it slides. Gohan braces himself against the stretcher. Goshin gets between the open doorway and Goku.

"Close that!" Bulma shouts.

"I didn't open it," Roshi says.

Piccolo hovers outside. "Your boys are coming with me."

"No," Goku says.

"You saw what they did to Raditz. They could be strong enough to stop the others."

"They're four years old."

"The Saiyans won't care."

Gohan moves close to Goshin. "I want to go home."

Piccolo looks at him. "Go home, then wait there until the Saiyans find you?"

"We'll train," Goku says. "But you're not taking my sons."

Piccolo's eyes narrow. "You can barely sit up."

Goku pushes against the stretcher with his good arm. Pain stops him halfway, but he keeps his eyes on Piccolo.

"Their mother and I will decide what happens to them."

"Your wife didn't fight Raditz."

"She's still their mother."

Piccolo extends his new hand through the doorway. Gohan lifts from the floor.

"Gohan!" Goshin catches his brother's wrist.

Gohan's feet slide toward the open door. Goshin digs his heels into the floor and pulls with his good hand. Piccolo's fingers close, and both boys move another inch.

Goshin fires a short burst at Piccolo's hand. Piccolo twists aside. The force holding Gohan vanishes, and both boys fall against the stretcher.

Roshi pulls Gohan away from the door. Goshin is already on his feet.

"Your arm came back," Goshin says.

"A lizard can do the same thing," Piccolo says.

"Mother won't let us bring lizards in the house."

"Goshin," Gohan says.

"What? She won't."

Piccolo's hand comes back through the doorway. Goshin strikes it with his bandaged palm. He winces, but Piccolo's fingers miss Gohan.

Roshi grabs Piccolo's wrist and twists it away from the boys. Piccolo pulls back, dragging Roshi to the doorway.

"Master Roshi!" Bulma calls.

Roshi plants his foot against the frame. "You're not taking them."

Piccolo kicks the frame beside Roshi's foot. Metal buckles, and Roshi loses his grip.

Goshin catches Roshi's sleeve before he can fall out. Gohan seizes the other sleeve and pulls with him. Roshi tumbles back into the cabin, and the three of them land against the medical case.

"Are you all right?" Gohan asks.

"I've been thrown out of better aircraft than this."

"You have not!" Bulma says.

"No," Roshi admits. "But I didn't want the boys to worry."

Goku raises his good arm. A small blast hits Piccolo's shoulder and knocks him away from the door. Goku grips the stretcher as pain catches in his side.

"Bulma, get us down!"

"I'm looking for a place!"

Piccolo recovers beside the aircraft. He holds out his palm toward the cabin.

"I'll ask once more."

Goshin moves to the doorway. Gohan catches the back of his shirt.

"He's going to hit Father!"

Piccolo fires.

Goshin meets the blast with his own. The two bursts collide outside the door. Goshin turns his hand, forcing Piccolo's attack away from the cabin.

A streak of energy clips the tail of the aircraft.

The cabin lurches. Roshi falls against the medical case, and Goku's stretcher jerks against its straps.

"I've lost the rear control!" Bulma pulls at the controls. "Roshi, keep that door clear!"

Goshin hangs onto the doorframe. Piccolo is already raising his hand again.

Gohan looks back at Goku. Then he turns toward the yellow cloud behind the aircraft.

"Nimbus! Come here!"

The cloud sweeps up beside the open door. Gohan snatches his hat from the stretcher, puts it on and climbs onto Nimbus, holding his injured shoulder close.

"Gohan!" Goku calls.

"He wants us, Father! I'll make him follow me!"

Gohan leans forward. Nimbus darts away from the aircraft toward the hills.

Piccolo turns after him.

"Goshin, stay with Gohan," Goku says.

"Goshin, stay with Gohan."

Goshin launches himself through the doorway. He catches up to Nimbus as Piccolo closes on Gohan from above.

Bulma swings the damaged aircraft after them. The controls shudder in her hands.

"Goku, I can't hold it like this!"

"There's a clearing by the river," Goku says. "Put us down there. Then we'll find them."

The aircraft banks toward the trees.

The damaged tail drags them to the left. Bulma corrects, and the nose dips. Roshi braces one foot against the stretcher and grips the frame.

"Bulma!" he says.

"I know!"

The river flashes beneath the windshield. Beyond it lies a strip of grass, bordered by trees. One dead trunk leans across the near end of the clearing.

"Can you go over it?" Roshi asks.

"Not with this tail."

Goku turns toward the open door. "Roshi, help me get my arm up."

Roshi lifts Goku's arm. Goku steadies his wrist with his other hand and aims through the doorway.

A short blast hits the dead trunk. It breaks near the base and falls away from the clearing. Goku's arm drops, and he cries out as the stretcher jolts.

"Goku?"

"I'm here. Bulma, it's clear."

Bulma lowers the aircraft toward the grass. The underside strikes first. Roshi holds Goku's shoulders as the cabin shakes, and the medical case knocks against his knee.

The aircraft skids through the clearing and stops short of the riverbank. Leaves settle over the windshield.

For a few seconds, the only sound is the engine ticking as it cools.

"Everybody all right?" Bulma asks.

"Ask me after I get my foot out," Roshi says.

The case has wedged his sandal against the stretcher. Goku reaches for it, but Roshi shakes his head.

"Don't move. I've got it."

He frees his foot and sets the case upright. The latch has held.

Goku looks toward the river. "They're still moving."

"We'll get to them," Bulma says.

She opens the front hatch.

At the Lookout, Popo watches the aircraft settle among the trees. He turns from the edge and fetches a rolled carpet from inside the palace. When he spreads it on the tiles, it lifts beneath his feet.

"Hold on," he says, looking toward the mountains.

The carpet carries him out over the clouds.

---

## A Request

King Yemma's stamp comes down on a page. The clerk beside his desk gathers a stack of papers that has fallen onto the floor.

A door at the far end of the hall shuts with a heavy bang. A furious voice sounds once from beyond it, then fades.

"That was Raditz?" Kami asks.

"He didn't like my judgment," Yemma says. "He tried to fight his way past me."

"Did he hurt you?"

"No. I sent him to Hell."

"You must be very strong. Perhaps you could train Earth's fighters."

Yemma looks at the queue. "And leave all of them standing here?"

A voice calls from the back of the line. "We're already standing here!"

"I can hear you," Yemma says.

Kami bows his head. "Then perhaps King Kai would be a better teacher."

"Better?"

"He may have more time."

"Careful, Guardian. Everyone comes to this desk eventually."

"Of course. I meant no disrespect."

Yemma sets down the stamp. Kami rests both hands on his staff.

"Two more Saiyans are coming to Earth. Our fighters need help."

"The fighter who stopped him is dead too?"

"No. Goku survived. He's badly hurt. Piccolo struck the final blow, after Goku and his sons fought Raditz."

"His sons?"

"Two children. They helped save their father."

Yemma's hand pauses over the next page. "Raditz didn't mention them."

"He was not fond of Earth."

"He wasn't fond of my office, either."

Kami glances at the fallen papers. The clerk has finished collecting them, although one corner of the stack remains bent.

"Could King Kai help us prepare?" Kami asks.

"King Kai? The road to him is a long one. Tradition puts Snake Way at about a million kilometres."

"You reached the end yourself."

"And I was tired when I got there."

"Goku is alive. Would King Kai even see him?"

Yemma looks toward the next person in the line. "King Kai decides whom he helps. I'll ask him, but I'm not promising an answer."

"Thank you."

"And tell your people not to send me another Saiyan like that one today."

Kami looks toward the closed door. "I'll do my best."

Yemma picks up his stamp.

---

## The Mountain House

Chi-Chi sits beside the telephone. Ox-King's hat is on the table between them.

"They might have gone fishing," Ox-King says.

"At Roshi's?"

"There's plenty of sea."

"That's what I'm worried about."

Chi-Chi gets up and goes to the door. The school paper is still pinned to the frame.

"Goku will say they're only playing. Then he'll kick a ball too hard, and the boys will go after it, and they'll fall in the sea."

"They know how to swim."

"What if a shark comes?"

"Goku can deal with a shark."

"And while he's dealing with it, they'll wash up on an island. They'll be hungry, so they'll reach for bananas, and a snake will bite them."

Ox-King picks up his hat. "That's a great many things."

"One snake can bite two boys!"

She grips the doorframe. "What if it's poisonous? What if it hurts them? What if they can't remember what they've studied?"

"Goku won't let that happen."

"Goku forgot his own lunch yesterday."

Ox-King puts on his hat. "I'll get the truck ready. We can drive to the coast."

"I'm coming too."

She looks at the telephone. "If they're back while we're on the road, they won't know where we've gone."

"Leave them a message this time," Ox-King says.

Chi-Chi takes up the receiver and rings Kame House again. This time, Turtle answers.

"Hello?"

"Turtle! It's Chi-Chi. Are Goku and the boys there?"

Turtle says nothing for a moment. Chi-Chi sits down.

"They aren't here," Turtle says.

"Where are they?"

"A man came to the island. He took Gohan and Goshin away."

Chi-Chi's hand tightens around the receiver. Ox-King stops at the door.

"Took them where?"

"I don't know. Goku and Piccolo went after him. Master Roshi, Bulma and Krillin followed in Bulma's aircraft."

"Was Goku hurt? Were the boys?"

"The man knocked Goku down. Goshin fought him, but he was hurt too. Gohan was awake when they went. Goku got up and went after them."

"And nobody has come back?"

"No. I went out into the water to look for them. I'm sorry I wasn't here when you called before."

Chi-Chi stands up. "We're coming to the island. If you hear from them, tell them I've gone there."

"I will."

She gives the receiver to Ox-King. He asks Turtle which way the aircraft went while Chi-Chi goes into the next room.

She comes back carrying a blanket and a small first-aid box. Ox-King is still holding the receiver.

"He says they went inland," he tells her. "He doesn't know where."

"Then we'll start at the island."

She takes the receiver. "Turtle, don't go looking by yourself. Stay where they can find you."

"All right."

"And if Goku calls, tell him I'm coming."

"I'll tell him."

Chi-Chi hangs up. Her hand rests on the telephone for one more moment, then she follows Ox-King out to the truck.

---

## Korin Tower

Krillin lands on the edge of Korin Tower and nearly runs into Yajirobe, who is carrying a bowl.

"Watch it!" Yajirobe holds the bowl away from him. "I nearly lost my lunch."

"Goku's hurt. Where's Korin?"

"Inside."

Yajirobe looks at Krillin's torn clothes. He sets the bowl down and follows him.

Korin is beside a small jar. Krillin kneels in front of him.

"A Saiyan attacked us," Krillin says. "Goku and the boys were hurt. Do you have any Senzu Beans?"

"How badly?"

"Goku's in the worst shape. He's alive, but he can't get up. Gohan's hurt his shoulder. Goshin took a blow to the head, and his hand's burned."

Korin takes the lid off the jar. Three beans roll into his palm.

Yajirobe leans closer. "Only three?"

"Only three ready," Korin says.

"Then I suppose you shouldn't eat any," Krillin says.

"I wasn't going to!"

Korin looks at the bowl Yajirobe has left by the door.

"All right," Yajirobe says. "I was going to ask."

Korin tips the beans into a little bag and ties it shut. "Take them. A whole bean will heal and fully restore whoever eats it."

Krillin accepts the bag. "Thank you. Two more Saiyans are coming, stronger than the one we fought. We have about a year."

Yajirobe's hands go to his sword. "What do they want?"

"The Dragon Balls. Raditz told them about the dragon before he died."

Korin's ears lift. "Then you'll need more than beans."

"I know. First I've got to get these to Goku."

Krillin tucks the bag inside his shirt and steps onto the edge of the tower. He turns toward Kame House, then stops.

Far away, two familiar powers flare. A third rises close to them.

"Piccolo?"

"What is he doing?" Yajirobe asks.

Krillin looks toward the distant mountains. "I don't know."

He takes off in that direction, with the bag held against his chest.

*This programme continues after a message.*

---

## The Chase

Nimbus skims the tops of the trees. Gohan holds on with both hands as the cloud slips between two tall columns of rock. His injured shoulder catches when Nimbus turns, and he shifts his grip.

"He's behind us," Goshin says.

"I know!"

"I can hit him if you turn."

Gohan pulls Nimbus around the nearer column. Piccolo follows through the gap. Goshin drops from above and kicks Piccolo across the shoulder.

Piccolo strikes the rock. Goshin comes after him, but Piccolo pushes off the wall and swings his new arm. Goshin ducks, catches the wrist and drives a knee into Piccolo's side.

Piccolo grips Goshin's shirt with his other hand. Goshin twists, tearing the cloth free, and flies backward toward Gohan.

"You pulled my shirt!"

"I noticed."

Gohan sends Nimbus between them. "Get on!"

"Get on!" Goshin repeats, and lands beside him. Nimbus rises over the columns with Piccolo close behind.

Gohan looks down. "There's a narrow place ahead. He won't fit beside us."

"He'll fit behind us."

"Then you hit him again."

Goshin smiles. "Then you hit him again."

Nimbus drops into a cleft between the ridges. Piccolo enters after them, and Goshin springs up from the cloud. He cups his hands, then checks the rock walls on either side.

"Gohan, go lower!"

Gohan ducks, and Nimbus carries him beneath Piccolo. Goshin fires a concentrated burst across the gap. It hits the ledge behind Piccolo and breaks it loose.

The falling rock cuts off Piccolo's path. He punches through it, but Goshin is already moving. He strikes Piccolo in the chest and follows Gohan out of the cleft.

The river curves below them. Gohan turns Nimbus toward it, looking for the aircraft. Goshin flies beside the cloud, opening and closing his bandaged hand. The cloth has not grown any redder.

"I can't see Father," Gohan says.

"We were higher than the river. Look for the clearing."

Gohan sees the open grass ahead. Before he can point it out, Piccolo comes over the ridge behind them.

"Gohan, down!" Goshin calls.

Gohan drops flat on Nimbus. Piccolo's arm stretches past him and catches the edge of his hat.

"Hey!" Gohan grabs it with both hands. The hat comes free, and Nimbus swerves as he pulls it against his chest.

Piccolo's hand reaches for him again. Goshin catches Piccolo's wrist and pushes it away from Gohan, but Piccolo closes his fingers around Goshin's ankle.

Piccolo swings Goshin toward the rock wall. Goshin fires at the stone in his path. The wall breaks before he hits it, and he comes through the dust with one hand still gripping Piccolo's wrist.

Gohan guides Nimbus along Piccolo's stretched arm. He hits the wrist with the edge of his hat. Piccolo loosens his grip long enough for Goshin to pull his ankle free.

Goshin kicks the hand away. Nimbus sweeps back under him, and he lands beside Gohan. Piccolo draws his arm back and fires at the cloud.

"Jump!" Gohan calls.

"Jump!"

Both boys push off Nimbus and drop. The blast passes over them and tears a trench along the empty far bank, splintering a tree. Rock and branches tumble into the river.

Nimbus dips beneath both boys and catches them. Gohan sits up first, then reaches for Goshin's good hand.

"Did he hurt your leg?"

Goshin rolls up his trouser cuff. A red mark circles his ankle.

"He didn't get my shoe."

"Why would he want your shoe?"

"I don't know. He took the arm back."

Gohan laughs once, then pulls his hat on again. Nimbus carries them around a bend in the river.

They reach a grassy shelf above a ravine. Nimbus stops. Gohan climbs off and turns to help Goshin, who lands beside him.

"There's blood on your bandage."

Goshin looks at the red patch. Gohan pulls a strip from the hem of his own shirt.

"Give me your hand."

"Give me your hand," Goshin repeats.

Gohan loosens the dirty wrapping. Pink skin covers part of the burn that was open at the crater. He leans closer.

"It stopped bleeding."

Goshin bends his fingers. "I told Father it was getting better."

Gohan wraps the clean strip around his palm. His shoulder makes him slow, but he gets the knot tight.

"That'll keep the dirt out."

"Thank you."

Goshin touches the side of his head.

"Does it still hurt?" Gohan asks.

"Only when I press it."

"Then don't press it."

"Then don't press it," Goshin repeats, and takes his hand away. Gohan looks toward the clearing.

"I should have gone straight back to Father."

"Piccolo was shooting at him."

"He followed me instead."

"And I followed you," Goshin says. "We're both here."

From the clearing below comes the distant scrape of metal. The aircraft settles among the trees beyond the river, one wing tipped toward the ground.

Gohan starts toward the path down. Goshin walks on his downhill side, keeping close enough to catch him.

"We have to get back," Gohan says.

"I can see the river. Father said he'd stay awake."

Piccolo rises over the edge of the shelf. Pebbles fall from his clothes.

"You two work well together."

Goshin steps in front of Gohan. "Go away."

"No."

"You shot at our father."

"And you stopped it. You can do that again when the Saiyans arrive."

Gohan looks toward the distant clearing. "We don't want you near him."

"You can't keep me away."

Goshin flies at him. Piccolo catches the first punch and pushes it aside, but Goshin's second hand is already moving. A burst strikes Piccolo's chest and drives him back over the ravine.

Goshin follows. Piccolo wheels beneath him and thrusts a hand toward Gohan. Goshin turns in midair and knocks the blast away from the shelf.

Piccolo reaches past him.

Gohan lifts from the ground. He grabs at the air, but the invisible force pulls him over the ravine.

"Goshin!"

Goshin strikes Piccolo's arm. Piccolo blocks him with the other and sends Gohan toward the opposite cliff.

Goshin opens his hand toward Gohan. His ki catches Gohan and bends his path away from the rock. Piccolo closes his fingers, dragging Gohan forward again.

"You broke Raditz's armour," Piccolo calls. "Do it again!"

Gohan reaches for Nimbus, but the cloud is still over the shelf. Goshin flies after his brother, keeping his hand extended.

Gohan throws his arms over his head.

The cliff explodes.

The blast knocks Goshin sideways. Gohan drops through a cloud of broken stone, crying out as a slab tips toward Goshin.

"Above you!"

Goshin raises both hands. His ki catches the slab and sends it into the ravine. He flies through the falling dust, catches Gohan around the waist and carries him clear of the remaining rocks.

They land on the far bank. Gohan clings to Goshin's shirt until the last stones have fallen.

Piccolo stands on the broken edge of the cliff. The marks from Goshin's blows are still visible on his clothes.

Gohan looks up at the broken cliff. "Did I do that?"

"You did it again," Piccolo says. "The power comes when you're frightened, and then it's gone. You need to learn to use it when you choose."

Gohan's hat has come off. He sees it beside a boulder and runs to pick it up. The four-star ball is still fastened to the top.

"I don't want to do it again!" He wipes his face on his sleeve. "I want to go to school. I'm going to be a scholar."

Piccolo looks at the ruined cliff. "A scholar?"

"Yes!"

"The Saiyans will kill you before you finish your first book."

"If I need to learn, Father can teach me."

"Your father would let you stop whenever you were frightened. I won't."

"Then stop throwing him!" Goshin says.

Piccolo looks from Goshin to the broken cliff.

"One day you may use that power against me."

"We already are," Goshin says.

"Yes. And I still need it."

Piccolo drops from the cliff and lands between the boys and the path back to the aircraft.

"I need fighters," he says. "I won't let those Saiyans take my world."

"It's our world too," Gohan says.

"For now."

Gohan pulls his hat down over his ears. "You still want to take it?"

"I told your father I did. Don't expect me to be gentle because we fought Raditz together."

Goshin moves beside Gohan. The torn bandage hangs from his hand. He lifts it anyway.

"You want both of us," Goshin says. "We're both here."

Gohan takes Goshin's other hand. "And we're going home."

Piccolo reaches toward Gohan. Goshin catches the wrist, and Piccolo tries to pull him forward. Goshin holds his ground, but the force lifts Gohan's feet from the bank.

Gohan scoops up loose grit and throws it at Piccolo's face. Piccolo flinches, and Gohan drops. Goshin jerks Piccolo's arm down and drives his shoulder into Piccolo's side.

Piccolo slides back a step. Goshin fires into the wet ground between them. Mud and water spray across the bank.

"The rock!" Gohan points to a fallen slab spanning the narrow end of the stream. He runs for it, with Goshin beside him.

They reach the far bank as Piccolo comes through the spray. Gohan pulls Goshin under the branches of a low tree. The river carries the broken leaves away.

Piccolo follows them into the trees.

---

## The River

The aircraft rests in the clearing. Its tail is blackened, but no fire is spreading through the grass.

Bulma jumps down through the open hatch. Roshi follows with the medical case. Goku is already working at the straps on his stretcher.

"Wait," Roshi says. "We'll help you."

"I can feel them. They're up the river, with Piccolo."

"Then I can follow them too," Roshi says. "Let us get you out first."

They ease Goku through the hatch. He puts his feet on the ground and stays there, leaning on Roshi until the pain in his side allows him to stand.

Bulma examines the damaged tail. "I can't fly this until I've fixed the control."

"Do what you can," Goku says. "Roshi and I will go after them."

Bulma opens the medical case and takes out the wrapped scouter. Its power cell is in a separate fold of cloth. She puts them in different pockets and closes the case again.

"Raditz used this to find strong fighters," she says. "If I can make it safe, maybe I can find Yamcha and Tien."

"They need to know about the Saiyans," Goku says.

"I sent Yamcha away after an argument. That doesn't mean I want him walking into this without a warning."

"Where did he go?"

"If I knew, I wouldn't need the scouter."

She closes her hand around the wrapped device. "I won't turn it on until I know it can't send our location."

She passes the case to Roshi. "The Dragon Radar is still inside."

"I'll keep it with us," Roshi says.

Goku takes one step and has to stop. He draws a breath, then tries again.

Above the river, the yellow cloud moves toward the ravine.

"Nimbus," Goku says.

It hovers for a moment between the clearing and the broken cliff. Goku looks up at it.

"Stay with Gohan."

The cloud turns back toward the boys. Goku watches it go, then follows the river with Roshi beside him.

---

## Preview

*Two boys hurry beneath the trees, with Piccolo following. Downriver, Goku and Roshi enter the forest. Far overhead, Krillin flies toward the mountains with a small bag inside his shirt.*

**NARRATOR:** Piccolo wants the boys' power, but neither brother wants to stay. Can Goku reach them before Piccolo makes his next move? And will Krillin find them in time?
