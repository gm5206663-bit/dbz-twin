# WRITING — how a chapter reads, and how it is shot

**Owns: the prose law and the camera.**

---

## 1 · The mix

Anime mass, manga economy. **Balanced, clean, readable** — under-styling fails and over-styling fails harder. **Readability outranks effect.** If a device is noticeable, the device has failed.

- **Anime gives:** time to sit in a room, weather that is doing something, a reaction held two seconds too long.
- **Manga gives:** the cut that arrives before you are ready, a page with one line on it, no transition at all.

---

## 2 · The band (arithmetic, not taste)

| | |
|---|---|
| length | **2,600 – 3,600** words |
| average sentence | **8 – 14** words |
| longest sentence | **60** words — a hard cap |
| dialogue | **42 – 70%** of prose lines — the gate's floor. **Aim for 45+**; below that a chapter reads like reportage |

---

## 3 · Sentences

1. **One idea per line.** A line that does two things is two lines.
2. **Verbs first.** He does not "become aware of"; he looks.
3. **Concrete nouns only.** A thing you could photograph or put on a table.
4. **No stage directions for feelings.** "He was sad" is a note to an actor.
5. **The last line of a scene is short.** Every time.
6. **Never explain the rule the scene just obeyed.**

---

## 4 · The camera — shot budgets in words

| Shot | Words | What it is |
|---|---|---|
| **pan** | 30–80 | the place, before anyone in it matters |
| **ritual** | 40–120 | a task done properly. The house's whole texture lives here |
| **stare-down** | 15–60 | two people, and the thing neither says |
| **clash** | 10–25 | two bodies, one exchange |
| **impact** | 2–6 | the frame that lands. No adjectives |
| **smear** | 3–8 | movement too fast to see; a verb and a direction |
| **reaction** | 3–10 | *someone other than the person who caused it* |

**A scene must name its shots, and the lengths must be uneven.** A scene of equal-length beats is a list.

---

## 5 · Devices, and the trap in each

| Device | Use | Trap |
|---|---|---|
| **the hold** | a paragraph where nothing happens and everything does | held too long it is boredom |
| **the reaction** | the cost, seen on a face that is not fighting | never on the actor of the action |
| **the world cut** | two lines away from the fight, to show its size | more than two lines is a subplot |
| **burst grammar** | short clauses into impact, one long line after | the long line must carry the aftermath, not the hit |
| **recovered silence** | sound returning in layers | once per chapter |
| **withheld frame** | cut before the thing is finished | the reader must know what was withheld |
| **the ritual** | hands doing a job correctly | never decorative — it must cost time |
| **cut home** | canon's own device: away from the event, to where someone is waiting | earns its place only if the wait is unanswerable |

---

## 6 · Before you write a scene, three questions

1. **What does he want in this scene that he cannot say?**
2. **Who reacts, and is it someone who did not cause it?**
3. **What is withheld, and from whom?**

No answers, no scene.

---

## 7 · Do not re-teach canon

**The cloud carries only the pure of heart.** Canon said so in *Dragon Ball*, at length, with jokes (C115) — so this serial **records** it (`STATUS §4`, `O023`) and **never stages it**. A scene that puts him on the Nimbus to show it is a scene the reader has already seen in a series that came first.

**The test for any such beat:** *has canon already made this point on screen?* If yes, it belongs on `STATUS` as a line with a witness, and the chapter's job is to **use** the fact, not prove it. The cloud may carry him across a valley in Chapter Nine because the valley is far — that is transport. It may not carry him across one sentence of explanation.

---

## 8 · Drawing a family resemblance

**Never a percentage.** "He is 99% his father" is a casting note from a producer, not a line of prose. A reader cannot see a fraction. **Draw what a camera sees:** the jaw, the hair that will not lie down, the way he stands with the weight on the same leg every time — and then the one thing that is his mother's, which is his eyes.

**The half-second is a shooting instruction.** When a scene needs him to think and the rule forbids interiority, give his face the lag: the room reacts, and *then* he does. Nothing is stated and everything is shown.

**One design line per chapter.** Seven sections of `STATUS` is a lifetime of work, not a paragraph's. A chapter shows **one** — the hands behind the back, the downhill side of the path, the refusal to eat what he did not watch being made — and says nothing about the rest.

---

## 9 · Forms, and how he never announces one

**He does not say the name of a transformation out loud, and neither does the narrator.** Super Saiyan 1, 2 and 3 are **finished** — perfected, internal, part of the engine. So there is **no hair-colour beat, no lightning, no counting, no "this is to go further."** The power is simply present, and the page proves it by what he breaks.

**What a scene may show instead:** the fidgeting stopping (`STATUS §1`), the room going quiet, an opponent's confidence arriving a second too early.

**Rage is cold and is never a scream.** **Super Saiyan 4 is earned at the ape** — write the fear before the fur, every time.

**And the gate is still a gate:** no god ki until the crossing, which is written **once, late, and one-directional** (`STATUS §12`). After it, god is his **floor** — never a power-up, never a switch. **Never write Blue.**

**The god rungs are a confession, not a fireworks display.** God 1, God 2, God 3 **leak** — write what being sensed costs him, never the glow. And **God 4 is silent**: when it arrives, the loudest thing in the scene should be everybody else realising they cannot feel him.

**A conversion, never a swap.** When he reaches for a rung, write the **reach** and then the wrongness of the result: the hair that does not come, the gold that is not there, the thing the enemy was waiting for failing to arrive. **His transformations are a mistranslation everyone else can hear — and the expectation is the weapon.**

**A god who is still a person.** After the crossing, **nothing is subtracted** (`STATUS §14`). He gets hungry, he laughs at the wrong moment, he sulks, he is wrong about people, he cries at the same things he cried at before. **Serenity is the failure mode of writing a god** — if a scene makes him calm, distant or above a joke, it is the wrong scene. The test: *could this man still be recognised by his mother?* If not, cut it.

**The era lock is the first thing to check in any scene.** At four he is a boy: hungry, polite, heavy for his age, one tail, no glow, no gold, no god. **He does what the others do and mostly no better than they do.** The ladder is a ceiling on file so that no future scene contradicts it — **it is not a costume to dress him in now.** If a chapter reaches above the first rung of `STATUS §13`, the chapter is wrong.


## §10 · The episode grammar — how a chapter is built like an anime

**A scene is not an episode.** A chapter that runs to 3,000 words in one room, with one lens and one day, is a *scene*, and it will read as a chapter of a novel rather than as twenty-two minutes of a broadcast. **Both are allowed here — but the form must be declared and paid for.** A chapter whose card says `FORM: EPISODE` gets 4,400–6,600 words and the grammar below; a chapter that says nothing is a scene and stays at 2,600–3,600.

**The eleven devices. A chapter that claims episode form carries at least seven.**

1. **Cold open.** One image before the title, no dialogue, and the world already running. Canon opens on weather and landscape because it is cheap and it is true.
2. **The narrator, who is a voice and not a mind.** He states time, place, and what is *not* happening. He may report events in other places — 「一方 そのころ…」 — **without the camera going there.** This is how the anime crosses the world without breaking a room.
3. **The title card.** After the cold open, and its own beat of silence. Ours goes in the chapter's own words: **EIGHT HOURS.**
4. **The countdown.** Canon counts down constantly — eleven months, two days, 11:43 a.m., three hours to the planet's end. **A chapter with a clock in it reads as an episode**, and the clock should be canon's own number where canon supplies one.
5. **Hard cuts.** Not transitions. A blank line and a new image at a different distance or a different subject: the yard, then the road, then the window, then the gate. **Never explain the cut.**
6. **The insert.** A hand, a dial, a page, a peg. The anime's cheapest and best trick: it tells you what a person will not say.
7. **The held frame.** One wide shot, longer than comfortable, with nothing in it but what is happening. Somebody standing at a gate. Two of them, small, from a distance.
8. **Sound before sight.** An engine before the truck, a voice before the man, a knock before the door. Canon does this relentlessly.
9. **The eye-catch.** A still frame at the middle with the programme's own voice over it, and then the same frame resumed. Ours: *"This programme continues after a message."*
10. **The loop-back.** A shot repeated at the end that opened the chapter, and the difference is the point.
11. **The preview.** The anime's closing device, and the most useful thing in this file: **it lets a chapter say what it did not show.** Two or three images from the next chapter, the narrator's flat promise, and a title in quotes. **It is also a promise to the reader that the rest of the world exists**, which no scene-form chapter can make.

**What the grammar must never become.** Not a script. No camera numbers, no timecodes in the prose, no shot list in the body — **the devices live in the writing, not in the margins.** The countdown is a bolded line. The cut is a blank line. The held frame is one unbroken paragraph that refuses to move on.

**And the POV law survives it.** Camera movement is not interiority. **The narrator may say that a man is running down a road a million kilometres long; he may not tell you what the man is thinking.** Cutting is not entering. `STATUS §1` and the no-interiority rule hold at any frame size.

## §11 · How to write a fight

**A fight is not a sequence of blows. It is a geography, a clock, and a bill.** Canon's own fights are built that way and prose keeps failing at them because prose tries to narrate the *exchange* instead of the *weather around it*.

**The clarity law comes first, because the other seven are worthless without it.**

**0 · A fight must be followable in one pass, by somebody who is tired.** Every paragraph answers three questions out loud, and if any answer is missing the paragraph is wrong:
- **Where are they?** (a stone, a wall, a door, a hill, a drop)
- **Who is acting?** (a name, a pronoun with one possible owner, or a thing)
- **What changed?** (somebody moved, something broke, something was decided)

**The temptation — and it is the one I fell into — is to render a fight by its effects alone:** dust in the shape of a boy, a hole in a hill, a silence. **That is beautiful and it is not enough**, because the reader has to *infer* who did what, and inference is where a reader gets lost and stops. **Effect-only prose is a mood; a fight needs a sequence.** Keep the effects — they are what makes it feel strong — but **put the events in order, with subjects, before and after them.**

**Two rules follow, and they are hard rules.**
1. **One action per sentence.** Not one action per paragraph, not one per clause. *"Gohan gets behind him and grabs the tail with both hands"* is two sentences or it is one too many.
2. **No pronoun with two possible owners.** With two boys in a scene, *he* is a guess. **Name them.**

**And every specimen carries a crib.** `CRAFT` gives each fight a **plain-words version first** — numbered, adjective-free, in the simplest English available (`O052`). **If the crib is unclear, the prose is broken, not the reader.** The crib is not a courtesy to beginners; it is how the writer proves the fight has a sequence at all.

**The seven laws.**

1. **Draw the room before anyone moves.** The line, the wall, the door, the drop, the thing that must not break. **If the reader cannot say where the edge is, nobody can be in danger.**
2. **Set the terms.** A rule that is not a rule of strength: a stone, a count, a promise, a person asleep behind you, a roof. **The terms are the tension**, because the reader can win or lose alongside the fighters.
3. **Speed is a consequence, never an adverb.** Nobody moves "quickly" or "in the blink of an eye". **Empty space, dust still holding the shape, a hole in the ridge, crust broken at the heels.** The reader computes the speed from the damage.
4. **Keep the ledger.** Every chapter with violence in it can list what broke, in order, in objects. **Damage is bookkeeping and somebody keeps the books** — canon's fighters count stamina, teeth, and seconds, and so does the prose.
5. **Cut to the onlookers, and let them be ordinary.** The villagers, the animals, the machine, the man with the hoe. **Their ignorance of what they are seeing is the scale.**
6. **One impossible thing per scene, then strict physics.** A boy's fist through a ridge — and after that, real gravity, real dust, real breath. **Two miracles in a paragraph is a cartoon; one miracle in a page is a horror.**
7. **End on the room, not on the winner.** The hole is still in the ridge next chapter. **A fight that leaves no trace did not happen.**

**The turn.** A fight must turn on something **said or done before it began** — a teaching, a rule, a held-back thing, a promise. **A turn that arrives as new information is a cheat.** In canon the first Super Saiyan is the purest example: the turn is a death that happened one scene earlier (`C137`).

**The loser.** Give them a physical habit, not a speech. Hands behind a back. A hand that keeps going to a shoulder. **Habit is how the reader learns what the fight cost, three chapters later, in a quiet room.**

**Banned in fight prose:** blow counts ("the first, the second") · named attacks of ours (names belong to canon, `RULES`) · numbers of any kind · "he felt" and its family · the word *power* as an explanation · describing a technique's mechanism · the phrase *in the blink of an eye* · any sentence whose subject is the fight rather than a person or a thing.

---

## §12 · How to write the impossible

**Supernatural events are not described. They are measured.** A blast is not a light; it is what the light does to the hill, the birds, the water, the dust, and the silence after.

**The eight laws.**

1. **Effect, never mechanism.** No name, no source, no explanation. **A line, then a point the size of a coin, then nothing.** Canon never explains its own best moments and neither do we.
2. **One impossible thing per scene.** Everything else stays strictly physical — weight, grit, breath, wind. **The impossibility is only as strong as the reality it interrupts.**
3. **Sound arrives late.** Light first, then the report, then the roll, then the echo. **Latency is how a page makes something feel enormous** — the delay *is* the size.
4. **Pay for it in objects.** Crust, windows, water in a dry channel, dust that will not settle on a warm surface. **The cost is never in the character's feelings** — that is what the no-interiority rule is for.
5. **Kill one thing and do not discuss it.** A tree simply not there, and not in pieces anywhere. **Absence is the strongest effect available** — canon does it with a moon (`C127`).
6. **State the uncanny; never flag it.** *The second light is quieter than the first* — and then go on. **Do not add "which is impossible", "the wrong way round", "as though the rules had changed".** The reader already knows it is not normal; **remarking on it is the narrator stopping to admire the effect**, and it breaks the flow. **Say the thing and keep walking.**
7. **Report, don't rhapsodise.** A number for a silence (eleven seconds), a plain statement of what is left. **The narrator states; the reader is moved.**
8. **Go to the world's eyes when you can.** The birds, the mountain, the water, the machine. **The most supernatural passage in this docset has no people in it at all** (`CRAFT` Specimen B).

**Where the era lock bites.** At four he has no gold, no god, no glowing anything (`O045`). **The supernatural available to this serial now is canon's own and small:** an adult who can put a fist through rock, a boy who lifts what a man cannot, a demon who makes a garment out of nothing, a machine that prints a number. **That is enough.** The ladder is documented so that the day it is unlocked, the writing already knows how to measure a miracle.

## §13 · Name them

**A name is not a reward for reaching the end of a paragraph.** Once a character has been named on the page, the prose calls them by that name — every time. **No "the taller boy", no "the small one", no "the demon", no "the woman with blue hair".**

**The three legal exceptions, and there are only three.**

1. **Before the name is known.** A stranger may be "the man at the gate" until he is introduced, and the moment of the name is a deliberate beat. **Use it once, then never again.**
2. **For a character who is never named at all.** The teacher on the bicycle, the man with the hoe, the shopkeeper, the driver. **They stay descriptions, because they are furniture with faces** — and that is a choice, not an accident.
3. **Inside dialogue.** People call each other "the old man" and "your grandfather" and "boy" out loud, and they will keep doing it. **Quotation marks are a licence. The narration is not.**

**Why this rule and not a matter of taste.** An epithet tells the reader *how to see* a person instead of who they are — it puts the camera between the reader and the character, which is exactly what a no-interiority book cannot afford. **It also leaks information the narrator should not have.** "The smaller one" is a judgement; "Goshin" is a fact. And in a serial with two four-year-old sons, **"the taller boy" is not a style, it is a puzzle** — the reader stops to sort them out, and the scene is gone.

**The tell that you are doing it wrong:** if a character's epithet changes as the scene changes — "the tall man", then "the man with the scar", then "the scarred man" — **the prose is auditioning synonyms for a name it already knows.** Cut all of them.

**Gated.** `check_names` fails any chapter or specimen that uses a descriptive epithet in narration for a character the same file names. If the epithet is a real choice, the character must stay unnamed — in which case declare it in the footer as furniture.

## §14 · No riddles — the law for invented material

**Canon is easy to follow because the audience already knows the story. Invented material has no such help, and it fails in a specific way: it makes the reader decode.** A teacher who speaks in proverbs, a boy who announces a fact as if it were a mystery, a line that sounds wise and means something the reader has to guess at. **That is what a riddle is, and it is a bug, not a style.**

**The laws.**

1. **Everybody says what they mean.** A character may be rude, blunt, contemptuous, or silent. **A character may not speak in aphorisms.** *"If you can't beat a thing, beat the thing it needs"* is banned permanently. **Canon's teachers say: "Grab his tail."**
2. **State the want and the stake in the first three lines of any invented scene.** Who wants what, and what happens if they do not get it. If a scene has to be explained afterwards, the explanation belongs at the front.
3. **One character must say the meaning of the scene out loud, once, in plain words** — and it must be a person who would know. Piccolo says the verdict. Roshi says what the machine does. **The narrator does not imply it.**
4. **No revelation that is only a revelation to the reader.** Gohan noticing a tail is not a twist; it is a boy noticing a tail, and he says so, and then someone answers him.
5. **A question asked in the scene gets answered in the scene.** If a character asks "what do you mean?", the answer arrives within a few lines. **Canon does exactly this** — Goku asks, and somebody explains, at length, twice.
6. **The stranger test.** Read the invented paragraph to somebody who has not read the chapter. **If they cannot say what happened in one plain sentence, the paragraph is wrong — even if it sounds good.** Good-sounding and unclear is the exact failure mode of original prose.

**What this does not ban.** Silence, contempt, jokes, a character refusing to explain, a mystery the *characters* also cannot solve. **A character being mysterious is fine. The writing being mysterious is not.**

**A named situation before the scene.** Every specimen opens with **WHAT THIS IS**, one sentence, no style (`O053`). Same for any invented chapter beat that is not obvious from canon. **Name the situation, then write it.**

**Not machine-checkable, and said plainly.** No script can tell an aphorism from a line of dialogue. **This law is kept by the stranger test and by the reader**, and the reader saying "I don't understand this" is the check failing, not the reader.

## §15 · The flow — how the impossible is allowed to happen

**Three rules and a shape.** The rules are about what not to do; the shape is what is left when you stop doing them.

**Rule one — never tell the reader they could not see it.** *"In the blink of an eye", "faster than the eye could follow", "nobody saw him move", "so fast it was invisible"* — **all one move, and it is the weakest move available.** It describes an absence instead of an event, and it asks the reader to be impressed on the narrator's instruction. **Write the displacement instead:** he is at one stone, then he is at the other, **and the ground says what happened** — the dust rings, the feet in it to the ankle, the boy on his back four paces past his stone. **The reader does the arithmetic and feels the speed; the narrator does not report that it was fast.**

**Rule two — do not compare the impossible to something ordinary.** *Like a door closing · like pages turning · like water out of a tipped bowl · like sand out of a fist.* **Each of those cuts the event down to furniture**, and the moment a boy's strength leaving him is "like a bowl tipped", the reader is looking at a bowl. **The impossible gets described in its own physics: weight, pressure, heat, light, silence, and the state of the ground afterwards.** Save the ordinary comparisons for the ordinary — a boy's breathing, a chicken, a telephone.

**Rule three — do not stop to explain that it is strange.** The reader knows. **One sentence of event, then the next sentence of event.** No narrator's aside, no "and that should not have been possible". **Flow is the absence of commentary.**

**The shape, and it is the same shape every time:**

> **cause you can point at → the event → the consequence left in the world.**

Goshin puts his hand on Gohan's chest and pushes. Gohan is on his back. The dust is still in the air. **Three sentences, no gaps, and nothing the reader has to fill in.** If a step is missing, the reader supplies a wrong one — and that is what "I don't understand" actually means.

**And do not let a character announce what the scene already shows.** A boy saying *"he has a tail"* when the reader has been looking at the tail for two chapters is **a revelation to nobody**; the line reads as a riddle because it has no work to do. **Let the person with authority give the order** — *"His tail. Take it. It is the only part of him that is not strong."* — **and let the boy do it.**

## §16 · The scale — decide the number before you decide the damage

**The error I made, and it is the worst kind: a fight written at the wrong power level.** Two boys of four and five, one at about four hundred and one at about seven hundred, and I had a punch put a hole in a hill. **That is a hit from six hundred episodes later.** The prose was fine. **The scale was false, and false scale cannot be repaired by any amount of good sentences.**

**So every fight begins with the numbers, and the numbers produce the bill.**

1. **Name the numbers first**, in the card: `SCALE: Goshin ~400 · Gohan ~700`. Where a number is not canon, say it is ours.
2. **Then write what breaks.** The damage is not a matter of taste; **it is arithmetic on the number.**
3. **Then write the fight**, and nothing may break that is not on the bill.

**Two currencies, and they do not convert.**

1. **The body** — a punch, a push, a kick, a footfall, a throw. **Small, local, predictable.** This one does scale roughly with the number.
2. **The charged attack** — a named technique, stood still for, aimed, paid for in seconds. **Enormous, and canon never reconciles it with anything.**

**The proof is already in our own record.** Piccolo **removes the moon** at a reading of about **322–408** (`C127`, `C130`). Nappa **takes a city off the map** at about **4,000** — a claim the record marks **Tier II, unread at dialogue level**, and which does not need to be true for the argument, because the moon alone settles it. **A moon is not a hundredth of a city.** Either Piccolo's attack was a thousand times more efficient than Nappa's, or the number is not a measure of damage at all.

**It is not a measure of damage at all.** The number answers exactly one question: **who beats whom.** It does not answer *what breaks*.

**So damage is derived from feats, not from figures.** Declare the rung and declare the feat being measured from:

| rung | the body | the charged attack, as canon has shown it |
|---|---|---|
| **5** | nothing | nothing |
| **322–408** | stone splits underfoot; a boulder cracks; a man is thrown eight paces | **the moon is gone** (`C127`) — *the outlier that proves the rule* |
| **710–1,330** | a hull broken from the inside; a headbutt hurts a 1,500 | **armour and a chest pierced** (ep. 4) |
| **1,500** | two fighters at four hundred cannot touch him | a combined charged attack is required |
| **~4,000** | buildings come down | **a city gone** — Tier II, to be verified before it is cited |
| **anything** | — | **and the same rung can do both ends of this**: the moon at four hundred, the city at four thousand. **The figures are not a ruler.** |

**And the serial's rule, which is stricter than canon's.** We do not invent a feat to suit a scene. **If a fight needs the world broken, it must use a feat canon has already shown a comparable fighter perform, and the attack must be charged, aimed, and paid for.** Otherwise the damage is the body's damage, and the body's damage is small.

**The rule of the era.** `STATUS §9` says what his number is. `STATUS §13` says what he may ever become, and it is locked. **Between those two facts, every fight in the current era has a maximum damage, and it is small.** Write small, and write it exactly — **a small fight that is exact is frightening. A big fight that is not earned is a cartoon.**
