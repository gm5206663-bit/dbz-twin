# STORY — the world, the people, the scale

**Owns: the laws of the world, the clock, who is where now, how the cast sounds, and every number.**

---

## 1 · The laws

1. **Canon is the floor, not a track.** There is no parallel line to keep in step. He lives inside canon's world and changes it by being in it.
2. **Anime governs; manga corroborates.** Where they disagree, a ruling decides. **Never averaged** — a blend exists in neither source.
3. **Continuity:** DB + Z + Super + all films. Films need a verdict each (`OPEN-6`); the opening arcs touch none.
4. **He is native.** No foreknowledge, no meta-knowledge, ever. *(Declared exception to house rule F0.)*
5. **The OC changes every scene he is in.** If a scene would read the same without him, cut him or cut the scene.
6. **Never restamp an accepted hash.** An accepted chapter is corrected by a dated note, not a rewrite.
7. **He does not outrank Gohan in canon's own thread.** Canon's story is Gohan's; ours runs alongside it.
8. **The gate.** He cannot take Super Saiyan God **as a form.** The ritual would adapt into a divine Talent and promote his baseline, with no way back down (`STATUS §12`, O031, O032). **Late, once, one direction — and the base afterwards is what he is.**
9. **The ladder is a floor, not a staircase.** Super Saiyan 1–3 are perfected, so they are never announced; **Rage** is his, **Super Saiyan 4** is earned at the ape, and **Blue is impossible** — and because the Talent **never lets a thing be lost** (`O041`), **every golden rung he reaches for comes back divine** — God 1, 2, 3, each louder than the last — crowned by **GOD 4**, the god worn inside the ape's body (`STATUS §13`).
10. **The promotion is total, and it subtracts nothing.** The Talent becomes divine and works on everything (`STATUS §14`): his forms, his techniques and **his children** — born divine, not mortal. **And he loses nothing** — temper, appetite, jokes, grief, mistakes. Canon's god form calms a Saiyan (C119); **his does not, because nothing is taken.** (`O042`–`O044`)
11. **The era lock.** At four, and through the Z-era arcs, **he is mortal and ordinary** (`O045`). The ladder in `STATUS §13` is a **locked ceiling**: no golden hair, no god ki, no divine anything. **Writing him as anything more is a period error, not a power-up.**
12. **Canon where canon speaks; ours where it does not — and ours says so.** Every rung canon printed is played by canon's rules. Every rung it did not print is declared in `STATUS`, with the mark that it is ours.

---

## 2 · Names

- **Human: Son Goshin** (悟心) — carries the 悟 his brother carries.
- **Saiyan: Broc** — same root-vegetable register as Kakarot, Raditz, Vegeta.
- **Who says what:** the house says Goshin from birth. **Broc is first spoken by Raditz, in ep. 2, in daylight, on the island**, and nobody there has the standing to refuse it. The refusal becomes his mother's in Chapter Three.

---

## 3 · The clock — two days

**The date: 12 October, Age 761** (Daizenshuu 7 via W-23). **Mid-autumn.** The guidebook assigned it working backwards from later anchors, so it is a date of record rather than a line of dialogue — and it is the first date this serial has ever had.

**Day one (ep. 1), on the mountain**

| Hour | Mountain | Elsewhere |
|---|---|---|
| morning | Chi-Chi calls two names from the yard; Goku fells a tree and carries it up the slope with a boy on it | — |
| morning | he comes in, finds the boy missing, says he cannot have gone far, and goes to fetch him. **She stays.** | a farmer is read at **5** and killed |
| midday | Gohan alone: the sabertooth, the hat, a log he cannot get back from | the glass sounds again: a larger power at **12,909**, and he goes to it — *"this time it is definitely Kakarot"* |
| afternoon | Goku finds him from the cloud | a city, seen from above |
| evening | Goku takes **both** boys; the mother watches them go | Piccolo reads **322**, fires, and it does nothing. **He is left shaking** |

**Day two (ep. 2), on the island** — the ten beats in `CANON §4`, ending past dark with both boys in the air, and an ultimatum: **about a hundred humans, killed and piled where he stands, by this time tomorrow.**

**The same days, on the mountain (eps. 3–6, anime-only) — read, not summarised:**
| Ep. | What she is doing | What she knows |
|---|---|---|
| 3 | the cram-school homework is only half done; she sighs | nothing. She thinks they are having fun at Roshi's |
| 4 | humming, holding a returned test paper — eight hours a day paid off — wishing they would come home so Goku could see it | nothing |
| 5 | telling herself she should have gone too — and then **the Ox-King drives in with armfuls of presents calling for Gohan** | the question is in her yard and she has no answer |
| 6 | her worry running away out loud; **she rings Kame House and gets an answering machine** | **still nothing.** Krillin is being sent, and has not arrived |
| 7 | Krillin at her gate, rehearsing and failing; then dinner, and her rage at a man who is late | **still nothing.** She is angry at the wrong thing, at the wrong person, on the last day it is still bearable |
| 8 | she goes to Kame House herself, because the phone gave her nothing | **the telling.** Roshi says it in two words and she goes down. **Her husband is dead and her son is with the demon who killed him** |

She is never at the battlefield, and she is **not told in ep. 6** — that is the next chapter's whole floor.

---

## 4 · Where he is now (end of Chapter Three)

**He is off the map, with his brother, in Piccolo's keeping** (C108, O018) — and the mountain knows nothing about it. **Who he *is*** — body, biology, the scale, the certified traits — lives in **`STATUS.md`**, one line each, with its witness.


| | |
|---|---|
| **Where** | carried, in the dark, going where the man goes |
| **Body** | unhurt. No bill paid yet — and that is the frightening part |
| **Known to his family** | he is strong; a scouter read **400** on him at rest |
| **Knows** | that a stranger called him Broc, and that nobody on that island said otherwise |
| **At home** | three bowls on the step, one bigger than the others. The axe is still above the beam. Nobody has gone inside |
| **Not yet spent** | the tail, the moon, the rage |

---

## 5 · The cast — voice law and never-list

**GOKU** — short flat sentences; questions are sincere; no sarcasm, no explaining a feeling. Affection is *doing the task*. **Never:** boasts, withholds a discovery, uses a word he has no reason to know. *Around him power is ordinary — that is why a born-100 child stays likeable.*

**CHI-CHI** — fast and specific (times, costs, the rice, not "soon"); love arrives as a plan, fear as a rule; **she finishes her sentences.** **Never:** apologises for wanting them educated, is vague about money or time, or is written as a shouting joke. *She is the only adult with a plan, and she is not wrong.*

**GOHAN** — requests, not statements; cries easily and **recovers fast**; asks the reader's question and gets a bad answer. **Never:** braver than canon, sidelined in his own scene, or the twin's sidekick. **He is the lead of canon's book.**

**RADITZ** — contempt dressed as procedure; "Kakarot" is a title, not a question; never says please, never raises his voice — his politeness is the threat. **Never:** knows the boys exist before ep. 2, is curious about Earth, explains his plan.

**PICCOLO** — the fewest words of anyone; silence is an answer and the narrator does not fill it; never explains himself. **Never:** warm in the first arc, teaming up early, impressed out loud.

**ROSHI** — an old man who has decided to be funny so he does not have to be frightened; asks the dangerous question sideways. **Never:** lectures, or states the plot.

**BULMA** — the only one who talks about herself; sharp, practical, emotional at the wrong moment. **Never:** a prize or a voice of exposition.

**KRILLIN** — brave first, sensible second. **Never:** comic relief in a scene where somebody is about to be hurt.

**GOSHIN** — a four-year-old's vocabulary doing an adult's filing. **Exact questions** (*how many days*, not *when*); **an instruction said back word for word** before he does it, once; the answer arriving **half a second late** because he was still reading the room. He watches mouths, not eyes. **He shows what he can do; he does not report it.** **Never:** *pure*, a boast, an explanation of a feeling, a word he has no reason to know, or **"Broc"**. *Design: `STATUS §1–7`. The resemblance is drawn, never fractioned (R-22).*

---

## 6 · The scale — every number in this serial

| Reading | Figure |
|---|---|
| born, at rest | **100**, fully stable |
| four years old, at rest | **~400** |
| full rage | **1,500** |
| stability | ⚠ **unstable** — untrained, unmastered, running on instinct |
| the real figure | **the slope** — how fast he rises *inside* a fight |
| spoken in eps 1–2 — **all of them** | **5** (a farmer) · **322** (Piccolo) · distances **4,880** and **12,909** |
| printed in the guidebooks, **never spoken** in eps 1–2 | Goku **334** · 408 / 416 unweighted · Gohan **710 / 1,307 / 1** · Raditz **1,500** |
| ours | **400** — the instrument on him, Ch. 2 (`O005`) |
| **Raditz** | **1,500** (Daizenshuu 7, p. 82) |
| the Great Ape | **×10 base** — and it needs the tail and the moon |
| Gohan, four years old | 710 latent · 1,307 enraged · 1 after the headbutt |

**Two instruments, and they answer different questions.**

| | asks | says |
|---|---|---|
| **the cloud** | who is this | nothing out loud. It carries him, or he falls through (C115, O023) |
| **the scouter** | how much is this | **400**, and later every number on that island |

The order matters. **The cloud judges him first, in canon's own wordless way, in front of his mother**; the instrument gets its number on him second, in front of strangers. **Nothing in this serial may call him pure.** The cloud says it once; the prose never says it at all.

⭐ **1,500 is not a coincidence and it is not decoration.** At full rage, the boy burns at **exactly the reading of the man who took him**. Canon printed that number for Raditz; the author set it as the ceiling of a four-year-olds' rage before anyone checked. It is now checked, and it goes in the record as the sharpest thing in this serial.

**The loudness rule.** The episodes are *silent* about the scale: two numbers and two distances in two episodes, and the Great Ape is a roar, not a figure. So the serial may be loud where canon is loud, and where it is loud in canon's silence it says whose number it is.

**Rule:** a scouter in prose may only print a figure from this table, and only what that instrument would read in that moment. Two readings in one fight may disagree; that is the character, not an error. **A number not in this table does not exist yet.**

---

## 7 · The Talent, in six lines

Present from conception · non-sentient (no menu, no voice) · perfect genetic integration · a Great Ape state his body accepts without horror · **seen-once mastery of form** · **it never raises a battle power.**
The law under it: **seeing gives the shape; it does not give the power behind the shape.** Every use is paid for in heat, damage, food, sleep.
**The retention law, and its two faces.** The Talent **never lets a thing be lost** — it makes native what it adapts to, and then will not give it back (O041). Two visible consequences: against **godly ki** there is nothing to switch back to, so a ritual does not hand him a form, it **promotes his base** (`STATUS §12`); and against the **golden rungs** the base cannot revert, so **reaching for Super Saiyan 2 returns God 2** (`STATUS §13`). **He can hold back. He cannot un-have.**

---
