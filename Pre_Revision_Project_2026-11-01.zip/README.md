# THE TWIN — Dragon Ball Z

**Son Goshin** is Goku and Chi-Chi's twin son alongside Gohan. Raditz takes both. The Japanese Z anime is the baseline; manga, guidebooks, movies and later series are identified separately. Canon is a floor for the world, not a track that forces unchanged outcomes.

## Start here

- **`canon/RESEARCH.md`** — the deep research report: hybrid potential, growth, Namek recovery, scouters, training, tails, the Dragon Balls, later arcs and a transparent correction log.
- **`canon/SAGAS.md`** — the 291-episode navigation map and source cautions.
- **`CANON.md` / `canon/facts.json`** — witness registry, fact rows, source tiers and corrections.
- **`STATUS.md`** — Goshin's design, standing capability rule, growth and the separately ruled future god progression.
- **`STORY.md`** — world and continuity laws, the current state and moment-specific readings.
- **`WRITING.md`** — anime episode form, action clarity, names, supernatural flow and scale.
- **`CRAFT.md`** — three non-canon examples with plain-word descriptions and action.
- **`RULES.md` / `OPEN.md` / `HISTORY.md`** — the gate, decisions and the dated record.
- **`chapters/`** — three accepted chapter bodies; `Restored_Chapter_Two_Island_Moments.md` supplies five placed passages without silently rewriting Chapter Two. The corrected Chapter Four draft follows the abduction and episode 3; Chapters Five and Six cover the altered fight. **Chapter Seven — The Year Ahead** adapts episode 6, **Chapter Eight — The Long Way Home** adapts episode 7, and **Chapter Nine — The Message from the Tower** adapts episode 8 from the resulting branch. Chapters Four–Nine are drafts, not accepted by implication.
- **`canon/episodes.json`** — the 291-file search index; **not** a complete reading of each episode.
- **`canon/SCENE_COVERAGE_001.md`** — retrospective episode-1 ordered inventory, hat and forest gaps, and source limits.
- **`AUDIT_2026-11-01.md`** — project-wide audit, verified draft repairs, unresolved accepted-body issues and evidence limits.
- **`canon/SCENE_COVERAGE_002_003.md`** — ordered source-scene coverage for the corrected abduction and rescue, including authored changes and visual-evidence limits.
- **`canon/SCENE_COVERAGE_004.md`** — episode-4 beat inventory, draft coverage, the changed tail escape and the already-accepted Chi-Chi overlap.
- **`canon/SCENE_COVERAGE_005.md`** — episode-5 ordered inventory, two-boy causality, the changed outcome, later scouter beat moved earlier, home overlap and evidence limits.
- **`canon/SCENE_COVERAGE_006.md`** — episode-6 source-order inventory, the crater confrontation, Kame House telling, Senzu trip and Otherworld divergence, with evidence limits.
- **`canon/SCENE_COVERAGE_007.md`** — episode-7 source-order inventory and causal treatment: reunion, care, Kami, Piccolo, Baba, family decisions and displaced wilderness beats.
- **`canon/SCENE_COVERAGE_008.md`** — episode-8 caption baseline, secondary visual reports, moon/source-order issue and Chapter Nine divergences.
- **`canon/techniques.json`** — technique register.
- **`tools/index_eps.py`** — rebuilds the bounded caption search index.
- **`tools/check.py`** — mechanical checks and self-test; green does not independently verify canon.

## Source and reading status

All 291 Japanese SRT files were indexed and searched. Full spoken-caption reads cover **1–36, 49, 55, 59, 61, 65, 79–83, 183–184, 205–208, 256–257**; episodes 1 and 4–8 were reread for inventories and audit. Other episodes were read only in selected passages. Some files contain unrelated material after the DBZ ending; the index already uses a 29-minute heuristic, which is not a verified episode boundary. The files were redistributed through Kitsunekko; their broadcaster/official provenance has not been independently verified. Caption dialogue is provisionally Tier I. Selected episode-3 fan-gallery stills of the pickup and the Nimbus journey were inspected; their release is unverified. Episode-4–8 visuals are supported by secondary synopses and reports, not complete checked video; one episode-5 report was available only as search snippets. Read each episode fully and identify the remaining visual gaps before writing its scenes.

## Standing creative direction

Senzu fully heal battle injuries and restore strength: Goku and Gohan each ate one and are completely restored. Goshin refused the third because he did not watch it being made; he alone remains injured (`O103`).

Goshin's Kame House scan of **~400** is one authored snapshot, not a lasting level. For this abduction the user rules that Raditz cannot take Goshin conscious: the corrected draft shows an earned knockout first and a changed fight after he wakes (`O080`). His first Kamehameha has more raw ki than Goku's wave in that scene, but less practiced control; the separate **1,450** scan is an authored snapshot, not a canon value or ceiling (`O088`). His later **1,500** surge in Chapter Six is another authored moment, not the same reading or a cap (`O089`). Both brothers grow. The authored rule is that Goshin is never less capable than Gohan; this is not a canon equation and does not automatically set his rank against everyone else. He flies, uses techniques and learns visibly. His deliberate training masters or perfects what he already has before pursuing new abilities, with serious foundational work; instinctive emergency copying remains allowed (`O104`, `O105`). Fatigue, suppression and injuries can lower performance without erasing skills. Fight damage follows feats and context, not arithmetic on a printed number. No god ki in the current Z era; the user's separately ruled future god progression remains intact.

## Checks

```bash
python3 tools/check.py
# after intentional edits: reseal the living files, then run the check again
python3 tools/check.py --selftest
```

Accepted chapters are not silently rewritten. Chapter Two's conscious-capture passage is explicitly superseded in its footer and replaced by the full island fight at the start of Chapter Four; its supplemental scenes restore missed moments but do not fix every source-order issue in the older body. Chapter One's misplaced Raditz line, the Piccolo exchange, the undramatized forest/hat return and the moved city cut remain debts; the detailed episode guide is secondary, not video proof (`C181`). Chapter Three's accepted body is unchanged; dated footer notes supersede the incompatible Snake Way assertion and the §11 overnight outcome in the living-Goku draft. Its unanswered call is reused before Roshi's prompt call from Kame House, and its date and compressed clock remain open. The test paper, Ox-King visit and unanswered call are overlaps, not repeated arrivals or deliveries.

The earlier public GitHub repository, Drive backup, bundle and ZIP are snapshots from before Chapter Five; this working copy is not automatically synchronized to them.
