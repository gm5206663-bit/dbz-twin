# THE TWIN — Dragon Ball Z

**One original character:** Son Goshin (悟心) — Goku and Chi-Chi's son, Gohan's twin. Saiyan name **Broc**, which nobody on Earth says until Raditz does.
**Canon starts at:** DBZ anime episode 1. **Anime governs, manga corroborates. Canon is the floor, not a track.**
**Read so far:** **eps 1, 2, 3, 4, 5 and 6**, in full, from the official Japanese broadcast captions (W-30) — the episodes' own words, with timestamps, in `CANON §4`. **74 rows are Tier I.** All three chapters are gated on that text, and every card says `EVIDENCE: I`.

---

## The seven files

| File | Owns |
|---|---|
| **README.md** | this map. Nothing else. |
| **CANON.md** | how we know. Witness classes, the witnesses, grades, the two episodes read line by line, what is contested, what is ours, what is withdrawn. |
| **canon/facts.json** | what we know. Every fact as a row: id, tier, witness, grade. |
| **canon/techniques.json** | the technique ladder. Empty until something is performed on a page. |
| **STORY.md** | the world. Laws, the clock, who is where now, the cast's voices, the scale. |
| **STATUS.md** | the boy, **designed**: figure, face, speech, movement, appetites, habits, the fault — then biology, scale, certified traits, declared traits, and what none of it may mean. |
| **WRITING.md** | how a chapter reads and how it is shot. The band, the sentences, the camera, **the episode grammar (§10), the fight laws (§11), the supernatural laws (§12)**. |
| **CRAFT.md** | **three working specimens** — a fight, an explosion with nobody in it, and a first flight — **each with a plain-words crib first**, then the prose, then the reasoning. Ten drills. Not canon, not chapters: argument. |
| **RULES.md** | the gate, the pass, and the ten things failure has taught. |
| **OPEN.md** | what only the author can decide, in the order it blocks work. |
| **HISTORY.md** | the dated record of decisions and acceptances. |
| `chapters/` | the prose. |
| `tools/check.py` | the audit — the checks, and arithmetic only. |

**Read order, cold:** README → STORY → WRITING → CANON → RULES → the chapter you are working on.

---

## The pass

```bash
python3 tools/check.py            # 7 checks, arithmetic. Exit 0 or a list.
python3 tools/check.py --selftest # prove the audit still fails a dirty tree
# then reseal: sha256 of every file into MANIFEST.sha256
```

A change is not finished when the file you were editing is right. It is finished when `check.py` is green and the tree is sealed. **Counts are never written in prose** — `check.py` prints them.

---

## Where we are

- **Ch. 1 — *Two Names*** (ep. 1). The last ordinary day. The mother stays behind.
- **Ch. 2 — *The Second Name*** (ep. 2). The island. The instrument. Both boys taken. Cut home.
- **Ch. 3 — *Eight Hours*** (eps. 3–6, folded into one day). The yard, and nine hundred waiting hours. **Rebuilt to `FORM: EPISODE`** — cold open, narrator, title card, canon's own countdown from eight hours to none, twelve beats, an eye-catch, and a preview that names what the chapter refused to show.
- **The bands are form-aware:** `FORM: EPISODE` buys 4,400–6,600 words and the eleven devices (`WRITING §10`); a scene stays at 2,600–3,600. **Ch. 1 and Ch. 2 are still scenes, and are owed the same rebuild.**
