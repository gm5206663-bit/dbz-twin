# Chapter Six — The Brothers' Attack

The scouter's long signal breaks into rapid beeps.

Raditz still has one boot on Goku's chest. Gohan comes at him from the left, Goshin from the right. Across the crater, Piccolo holds two fingers against his forehead while the light gathers around them.

Raditz turns toward Gohan.

"A thousand?"

The numbers climb.

"1,307?"

He swings his arm toward Gohan, but Goshin's blast has already pushed it aside. Goshin closes in before Raditz can bring it back and strikes his damaged shoulder.

"Leave my father alone!" Gohan shouts.

He jumps.

His head hits the centre of Raditz's armour. The plate cracks. Raditz's boot lifts, and Goku rolls out from under it as both boys drive Raditz backward.

Raditz crashes against the crater wall. A ledge breaks away above him, and stones pour down over his shoulders.

Gohan lands on his hands and knees. For a moment he looks at the ground. Then he touches his forehead and turns toward Goku.

"Father?"

Goku has one arm wrapped around his ribs. He reaches for Gohan with the other.

"I'm here. Get away from him."

Goshin lands beside his brother. His burned palm is open, and he keeps the other hand raised toward the falling stones.

Raditz comes through them.

Goshin meets him with a punch. Raditz catches his wrist, but Goshin twists free, flies up and kicks him across the cracked breastplate. Raditz strikes back, sending Goshin against the slope.

Goshin plants his feet. Raditz follows, with one boot sinking into the loose stone. Goshin fires beside that boot, and the ground bursts under it. Raditz lifts his foot. Goshin pushes off the slope and comes up beneath his guard.

The scouter flashes as Raditz looks up.

"Broc. 1,500?"

Goshin says nothing. The dust rises around him, then scatters when he comes forward.

Raditz blocks the first blow. The next hits his injured shoulder, turning him toward the broken wall. He catches Goshin by the arm and throws him over it.

Goshin vanishes behind the stone.

"Goshin!" Gohan runs after him.

"I'm here!" Goshin calls.

Raditz's scouter sounds again. Its lens is aimed at Gohan.

"1?"

Gohan stops. A small stone slides from under his shoe.

Raditz touches his damaged armour. "That power came and went. It changes when you get angry."

Goku struggles to his feet. "Gohan, run!"

Raditz steps toward Gohan. "I'll kill you before you can do that again."

Gohan picks up the stone and throws it at him. Raditz knocks it away and strikes Gohan across the shoulder. Gohan falls beside Goku.

"He's only a child!" Goku says.

"A child who nearly broke my armour. The other one is next."

Goshin rises from behind the wall, one sleeve torn at the shoulder. Raditz aims at him, and Goshin turns the blast down into the crater floor. Rock bursts between them.

Raditz comes around the dust toward Gohan again. Gohan tries to get up, but Raditz is already reaching for him.

Goku seizes Raditz from behind.

---

## The Hold

Goku locks his arms beneath Raditz's and clasps his hands behind his neck. Raditz's fingers miss Gohan's collar by inches.

"Gohan!" Goku calls. "Get back!"

Gohan crawls away, holding his shoulder. Goshin drops between him and Raditz, then turns at Goku's voice.

"Goshin, get Gohan behind the wall."

"Get Gohan behind the wall."

Goshin puts an arm around Gohan and flies him the short distance to the broken stone. Gohan keeps his hat on with one hand as they land.

"Father's still there," he says.

Goshin looks across the open ground. Raditz is dragging Goku toward the crater, but Goku digs his heel into the loose soil and holds on.

Goshin rises above the wall, keeping Gohan in sight.

Piccolo's light is brighter now. His missing arm leaves a dark tear in the side of his clothes, but his right hand does not move from his forehead.

"Piccolo!" Goku calls. "How much longer?"

"A little. Hold him there."

Raditz drives an elbow back into Goku's ribs. Goku gasps, and his grip slips. Goshin flies in and hits the moving arm before Raditz can strike again. Raditz kicks at him, but Goshin drops below the boot and comes back up on the other side.

"You can't hold me," Raditz says.

"I'm holding you now."

Raditz braces both feet. He pulls at Goku's wrists, but the cracked armour shifts against his chest and he cries out. Goku tightens his hold.

Gohan takes a step from behind the wall. Goshin looks back at him, and Gohan points toward Piccolo.

"If he shoots, he'll hit Father too."

Piccolo hears him. "The shot will go through both of them."

"Then don't do it!"

"If Raditz gets free, he'll kill all of you."

Raditz strains against Goku's arms. "He wants you dead, Kakarot. You heard him."

"I heard," Goku says.

"And you still think he'll help you?"

"He's helping right now."

Piccolo lowers his chin, aiming along his raised fingers. "I won't miss another chance because you're in the way, Son Goku."

Goku looks toward his sons. His face tightens when Raditz shoves back against his ribs.

"If that's the only way," he says, "take it."

"Father!" Gohan starts toward him.

Goshin catches Gohan's sleeve. Gohan pulls free and runs toward Piccolo instead.

"Wait!"

Piccolo does not lower his hand. Gohan reaches him and catches the edge of his torn gi.

"Please. My father's there."

"I can see him."

"You can't shoot him!"

Piccolo looks down at Gohan. "Raditz is stronger than all of you. If he gets loose, who stops him?"

Gohan looks back across the crater. Raditz is dragging Goku sideways, one step at a time. Goku's feet leave two furrows in the dirt.

Goshin hovers close to them, looking from Raditz's hand to Goku's. He lifts his hands to his side. Light forms between his palms and spreads unevenly over his fingers. Goshin turns his wrists, and the light draws back between them.

Raditz sees it and twists, pulling Goku between himself and the boy.

Goshin lets the light go out.

Raditz smiles at him. "Go on. Use your father's attack."

Goshin drops toward his injured shoulder instead. Raditz throws his head back, striking Goku's face, and reaches for Goshin with his free hand. Goshin slips under it and hits the wrist, but Raditz catches hold of Goku's arm before Goku can change his grip.

"There," Raditz says. "Now neither of us can move away."

Goku pulls, and Raditz pulls with him. Raditz looks toward Piccolo, and the scouter begins to sound.

"1,480! Kakarot, let me go. I'll leave."

"You said that before."

"I'm your brother!"

"You took my sons."

The light leaves Piccolo's forehead as he draws his hand back.

Gohan releases Piccolo's clothes.

---

## The Shot

Gohan runs down the slope toward his father. His hat slips off and tumbles into the dirt, but he keeps going.

"Gohan, stay back!" Goku calls.

Gohan stops a few steps away. Raditz's hand is closed around Goku's wrist. Goshin is pulling at Raditz's other arm, using his good hand; his burned palm scrapes against the armour and makes him flinch.

Gohan bends and scoops up a handful of loose dirt.

Raditz looks at him. "You again?"

Gohan throws the dirt at his face.

Raditz flinches and turns his head. His grip opens for an instant. Goshin catches Goku around the waist from Raditz's side and pulls him sideways as Goku releases his hold.

Raditz reaches after them. Goshin strikes his arm away, and Goku drops hard onto the slope, rolling toward Gohan. Raditz catches Goshin by the torn sleeve and jerks him across Piccolo's aim.

"Goshin!" Gohan shouts.

Goshin looks up. Piccolo's fingers are already pointing across the crater.

"Makankosappo!"

Goshin tears his sleeve free and throws himself clear. The narrow beam crosses the place where he has been and strikes Raditz in the chest. Its spiral passes close enough to tear Goku's sleeve and burn a strip along his arm.

The beam goes on through Raditz and bores through the ridge beyond. Light flashes from the far face and streaks toward the horizon; stone splits along its path and crashes down both slopes. Gohan drops over Goku's legs as pieces fall around them.

Then the light is gone.

Raditz stands with one hand still outstretched. He looks down at the hole in his armour. His fingers open, and he falls backward onto the broken ground.

Piccolo lowers his hand. His knees bend, and he catches himself before he falls.

Goshin lands beside Goku. He reaches for him, stops when Goku makes a sound, then puts his good hand against the ground instead.

"Father?"

Goku's eyes open. He draws a short breath.

"Are you two hurt?"

Gohan shakes his head. Goshin looks at Goku's arm.

"It's burned."

"I can see that. What about you?"

Goshin opens his own burned hand. The bleeding Gohan saw earlier has stopped. He bends his fingers and puts the palm against the ground.

"It doesn't hurt as much," he says.

Goku tries to lift himself, but his arm gives way. Gohan catches him at the shoulder, away from the raw strip of skin.

"Don't get up," Gohan says.

Goku settles back. "All right. Just for a minute."

Goshin moves to Gohan's downhill side, between his brother and the loose edge of the slope. He keeps watching Raditz.

The scouter's lens is still lit.

---

## The Message

Piccolo walks down to Raditz. He stays outside the reach of Raditz's hands.

Raditz tries to rise. His arm folds beneath him, and he falls back. The scouter gives a small chirp against his face.

"Kakarot," he says. "You should have died with me."

Goku presses a hand to his ribs. "You're not getting back up."

Raditz looks past him toward the boys. "It won't matter. The other two are stronger than I am. They'll finish what I started."

Piccolo folds his remaining arm across his chest. "You won't be there to see it."

"And neither will you. Kakarot and his children will die with you."

"Perhaps. But when they kill Son Goku, his friends will bring him straight back."

Goku lifts his head. "Piccolo—"

Raditz stares at him. "Bring him back?"

Piccolo's mouth curls. "There are things on this planet called Dragon Balls. Gather them, and they'll grant a wish. Even someone who's died can be restored."

For a moment Raditz is silent. Then he laughs, though it catches in his throat.

"You fool."

The scouter chirps again.

"Everything we've said has gone to my comrades. They've heard about these Dragon Balls too."

Piccolo leans closer. "Gone where?"

"Across space. They'll come here, kill everyone on this planet and take your wish for themselves. Perhaps they'll use it to bring me back."

Gohan's hand tightens on Goku's sleeve.

"How long?" Goku asks.

"A year. That's all the time you have."

Goshin looks toward Gohan. Gohan looks back, then down at the Four-Star Ball on the hat lying in the dirt.

Piccolo glances at the glowing lens. "Two stronger Saiyans."

Raditz smiles. "You needed all of them to beat me. What will you do when the others arrive?"

Piccolo raises his hand.

"Piccolo," Goku says.

Raditz laughs again. Piccolo fires into his chest. Raditz's head falls to one side, and the scouter goes on glowing beside his closed eye.

Gohan catches Goku's hand in both of his.

"He was finished," Goku says.

"He was going to die anyway."

"You didn't have to do that."

"You asked me to fire through him."

"I know what I asked."

Piccolo bends and pulls the scouter from Raditz's ear. He presses the small switch at its side. The lens goes dark, but he keeps it at arm's length.

"It could still be sending," he says.

Goku looks at Raditz. For a while he does not speak.

Gohan follows his gaze. "Was he really your brother?"

"Yeah."

"You didn't know him."

"No. I didn't."

Goshin goes to pick up Gohan's hat. He brushes a streak of dirt from the ball with the edge of his sleeve and brings it back. Gohan takes it without putting it on.

At the mountain house, the Ox-King's truck stands outside the gate. Chi-Chi lifts a small shirt from the washing line and turns it so the sun can reach the other side. Her father sits on the stool, watching the road.

"That's Gohan's, isn't it?" he asks.

"Goshin's."

"I was just testing you."

"I've been washing both their shirts since they were born. You'll have to find me a harder question."

The Ox-King chuckles. Chi-Chi fastens the last peg and looks down the road with him.

---

## The Visitors

An engine sounds beyond the ridge. Gohan looks up first.

Bulma's aircraft circles over the crater. Krillin leans against the window, trying to see through the dust.

"There! By the wall!"

Roshi grips the back of his seat. "Goku's down."

"Piccolo's the one standing," Bulma says.

Krillin is already reaching for the door. "Bulma, land!"

She brings the aircraft down on the open ground beside the pod. Krillin jumps out and runs to Goku. Bulma and Roshi follow, with Roshi carrying the medical case from under the seat.

"Goku!" Krillin drops beside him. "Where are you hit?"

"Mostly here." Goku keeps his hand against his ribs. "And my arm."

Krillin looks at the burned skin, then at the torn front of his gi. "What happened to the other guy?"

Goku looks toward the crater floor. Krillin follows his gaze to Raditz and goes quiet.

Bulma kneels in front of Gohan. "Can you move your shoulder?"

Gohan lifts his arm a little and winces.

"All right. That's enough."

"I'm all right," he says. "Goshin hit his head before. On the island."

Bulma turns toward Goshin. His hair is matted with dust, and one side of his sleeve is torn.

"Show me your hand."

"Show me your hand."

Goshin holds out the burned palm. Bulma looks at it without touching. "I'll get something clean for that. Your head hurts too?"

"A little. Not as much as before."

Gohan looks at Goshin's hand. "It was bleeding when we were up there."

"It's stopped now," Bulma says.

Roshi puts the case down beside them. "I have clean bandages here."

Goshin stays beside Gohan.

Krillin looks up at Piccolo. "What did you do to Goku?"

"The one on the ground did it. There are two more of them coming."

"Two more?"

"Stronger," Piccolo says. "Raditz said they'll be here in a year."

Roshi's hand stops on the latch of the case. "How do they know where to come?"

Piccolo holds out the dark scouter. "Because this sent them everything."

Bulma reaches for it, then stops. "You said it sent everything?"

"That's what Raditz told us."

"Put it down."

Piccolo lays it on a flat stone. Bulma takes a small tool from her pocket and crouches beside it. Krillin comes over with a torch from the aircraft while Roshi opens the case.

Bulma turns the earpiece until she finds a seam. "The lens is off, but that doesn't mean the rest is."

She works the tool beneath a narrow cover. It slides aside, exposing a small cell and a pin of light.

"There you are."

She pulls the cell free. The light goes out.

"Was it still talking to them?" Gohan asks.

"I don't know. I'm not putting the power back until I find out how it works."

Krillin looks toward the sky. "They heard about the Dragon Balls?"

"They did," Piccolo says.

Bulma wraps the scouter and the cell separately in her handkerchief. "Then we've got a year to do something about it. First, we're getting Goku out of here."

Goshin crouches beside Gohan while Roshi unrolls a clean bandage. Gohan holds the end off the ground as Roshi wraps Goshin's palm. When Roshi finishes, Goshin tries bending his fingers.

"Too tight?" Roshi asks.

"A little."

Roshi loosens the last turn. Goshin opens and closes his hand again.

"That's better."

---

## Far Away

On another planet, a broken wall collapses into an empty street. The inhabitants who fought there lie among the ruins.

Vegeta sits above the street with a piece of meat in his hand. He stops eating and touches the scouter over his eye. Beside him, Nappa looks up from the fire.

"Raditz is dead," Nappa says.

"Beaten by a handful of fighters."

"Are we going to Earth? We haven't finished here."

Vegeta looks out over the ruined settlement. "Did you hear what the green one said?"

"Those Dragon Balls? Any wish, he said."

"We'll go."

Nappa grins. "To bring Raditz back?"

Vegeta tosses the remains of his meal aside. "Why would I waste a wish on him?"

"He was one of us."

"He was weak."

Nappa glances toward the two space pods resting beyond the wall. "Then what do you want?"

"Eternal life. We could fight as long as we liked, and nothing would stop us."

Nappa's grin returns. "Now that's worth a journey."

---

## A Little Longer

Roshi has spread a folded stretcher beside Goku. Krillin returns from the scouter and crouches at the other end.

"Korin has Senzu," he says. "I'll go to the tower."

Goku looks at him. "You know where it is?"

"I can find it."

"Ask for enough for the boys too."

"Of course."

Krillin glances at Gohan and Goshin, then back at Goku. "Don't go anywhere without me."

Goku tries to smile. "I don't think I could."

Krillin lifts off the ground and rises over the ridge. His orange clothes become a small spot against the sky before he disappears.

Gohan kneels beside his father again. "You told us to get away."

"I did."

"I thought Piccolo was going to hit you."

Goku reaches for Gohan's hand. "So did I."

Gohan holds on. "I didn't know what else to do."

"You came back."

Gohan looks at his father's torn sleeve. Goku leaves his hand in Gohan's until the boy leans against his shoulder.

Goshin stands on Gohan's other side. He has one hand curled against his bandage, and his eyes are wet. He rubs them with his sleeve before Goku turns toward him.

"Goshin?"

Goshin looks at his father's mouth. "Can you stay awake?"

"I'll try."

"Until we get there?"

Goku glances toward the aircraft. "I'll try that too."

Goshin comes closer and takes the loose end of Goku's sash in his good hand. He keeps hold of it while Gohan sets his hat beside the stretcher.

Bulma returns with water and a clean cloth. "Goku, I'm going to wipe the dirt off your arm."

"Go ahead."

She begins carefully. Goku sucks in a breath.

"Sorry," she says.

"It's all right."

"You don't look all right."

"I'm getting better at lying still."

Gohan makes a small sound, halfway to a laugh. Goshin looks at him, then smiles too, a moment later.

Piccolo stands beyond them, looking at the two boys. Roshi sees him and straightens.

"You've helped enough," Roshi says. "You can leave now."

"Don't mistake this for help. Raditz was in my way."

Goku turns his head. "What about the other two?"

"They want the planet. I intend to keep it."

Gohan draws his hat close. "We want to go home."

Piccolo looks at him. "If those Saiyans come, home won't be safe just because you want it to be."

"Then we'll do something," Goku says.

Piccolo's eyes move from Goku to Goshin, then back to Gohan. "You'd better."

He steps away, holding his wounded shoulder. At the top of the slope he rises into the air and disappears beyond the ridge.

---

## One Year

Vegeta pauses beside his open pod. Nappa stands at the other one, still wearing his scouter.

"Kakarot's children," Vegeta says. "Those readings were high, even for Saiyan children."

"Could Raditz's scouter have been wrong?"

"You heard him after the blow. The child hurt him."

"Their mother is from Earth."

"Saiyan and Earthling blood." Vegeta looks toward the sky. "That may be why. Who knows what children like those might become? Super Saiyans, perhaps."

Nappa folds his arms. "If we had more children like those, we could make the Saiyans powerful again."

"And when they grew stronger than us?"

Nappa's grin fades. "Then we'd have a problem."

"Exactly. Once we have the Dragon Balls, everyone on Earth dies."

"Three days should be enough to clear the planet."

Vegeta climbs into his pod. "The journey will take a year. We might as well sleep."

Nappa lowers himself into the other seat. The hatches close over them, and the two pods rise from the ruined planet.

---

## Toward Home

Roshi and Bulma ease Goku onto the stretcher. Gohan walks beside it on the higher side of the slope, keeping the blanket clear of his father's injured arm. Goshin walks on Gohan's downhill side and steadies the frame as they carry it toward the aircraft.

The movement makes Goku catch his breath. Gohan walks close enough to see his face.

"Still awake?" Goshin asks.

"Still awake."

Goku reaches for the Dragon Radar at his belt. Bulma takes it from his hand and puts it in the medical case, away from the wrapped scouter.

"We'll take you back to Kame House," she says. "Krillin can meet us there."

"And Mother?" Gohan asks.

Roshi looks at him. "I'll call her as soon as we get to the house."

Gohan nods. He climbs into the aircraft beside the stretcher and makes room for Goshin. Goshin sits close to his brother, holding the edge of the blanket with his good hand.

Bulma checks the door and goes forward to the controls. The engine starts. Roshi secures the medical case while the aircraft lifts over the broken pod and climbs above the ridge.

Gohan looks out until the crater disappears beneath them. Then he turns back to his father.

Goku's eyes are closed.

"Father?"

They open again. "I'm here."

Goshin lets go of the blanket long enough to take Gohan's hand. The aircraft carries them over the forest toward the sea.

---

## Preview

*An aircraft crosses the sea. Far away, Krillin flies toward Korin's tower. At the mountain house, a telephone rests in its cradle.*

**NARRATOR:** The fight is over, but the two Saiyans are on their way. What will Krillin find at the tower? And what will Chi-Chi hear when the telephone rings?
